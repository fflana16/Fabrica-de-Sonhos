
export type MaterialType = 'LASER' | 'PAPELARIA';

export interface PriceValidity {
  id: string;
  value: number;
  startDate: string; // ISO string
  endDate: string;   // ISO string
}

export interface Customer {
  id: string;
  code: string; // CLI-001
  name: string;
  phone: string;
  whatsapp: string;
  instagram: string;
  notes: string;
  createdAt: string;
  isDuplicityRisk?: boolean;
}

export interface RawMaterial {
  id: string;
  code: string; // MAT-001
  name: string;
  type: MaterialType;
  thickness: number; // mm (apenas Laser)
  width: number; // mm (apenas Laser)
  height: number; // mm (apenas Laser)
  prices: PriceValidity[]; // Histórico de preços
  observation?: string;
}

export interface FixedCostItem {
  id: string;
  name: string;
  value: number;
}

export interface FixedCostsConfig {
  items: FixedCostItem[];
  desiredSalary: number;
  monthlyHours: number;
  machineHourRate: number;
}

export enum BudgetStatus {
  BUDGET = 'BUDGET',
  ORDER = 'ORDER'
}

export type PaymentMethod = 'Dinheiro' | 'PIX' | 'Débito' | 'Crédito';
export type BudgetType = 'LASER' | 'PAPELARIA';
export type FiscalType = 'NF' | 'RECIBO';

export interface BudgetItem {
  id: string;
  productName: string;
  theme: string;
  observation: string;
  budgetType: BudgetType;
  materialId: string;
  width: number;
  height: number;
  quantity: number;
  productionTimeMinutes: number;
  machineTimeMinutes: number;
  paintingTimeMinutes: number; 
  assemblyTimeMinutes: number;
  printingSheets: number;
  laminationSheets: number;
  
  materialCost: number;
  fixedCostApportionment: number;
  machineCost: number;
  serviceCost: number;
  totalBaseCost: number;
  selectedMargin: number;
  finalPrice: number;

  isManualPrice?: boolean;
  manualUnitPrice?: number;
}

export interface Budget {
  id: string;
  code: string; // ORC-001 ou PED-001
  orderNumber?: string;
  customerId: string;
  items: BudgetItem[];
  totalBaseCost: number;
  totalFinalPrice: number;
  fiscalType: FiscalType;
  customerTaxId?: string;
  customerAddress?: string;
  stateRegistration?: string;
  receiptObservations?: string;
  isDownPaymentMade: boolean;
  isZeroDownPaymentRisk: boolean;
  downPaymentMethod?: PaymentMethod;
  downPaymentPercent: number;
  downPaymentValue: number;
  downPaymentDate?: string;
  remainingValue: number;
  finalPaymentDate?: string;
  paymentMethodBalance?: PaymentMethod;
  status: BudgetStatus;
  createdAt: string;
  orderDate?: string;
  deliveryDate?: string;
  isPaidRemaining?: boolean;
  isDelivered?: boolean;
  isChurchService?: boolean;
  isRetroactive?: boolean;
  earlyDeliveryNote?: string;
  delayJustification?: string;
  amountReceivedAtDelivery?: number;
}

export interface AppState {
  customers: Customer[];
  materials: RawMaterial[];
  fixedCosts: FixedCostsConfig;
  budgets: Budget[];
  counters: {
    customer: number;
    material: number;
    budget: number;
    order: number;
    retro: number;
  };
}
