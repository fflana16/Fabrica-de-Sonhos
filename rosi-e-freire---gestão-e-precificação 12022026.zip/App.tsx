
import React, { useState } from 'react';
import { useAppState } from './store';
import MainMenu from './pages/MainMenu';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Materials from './pages/Materials';
import FixedCosts from './pages/FixedCosts';
import BudgetCalculator from './pages/BudgetCalculator';
import Orders from './pages/Orders';
import Receipt from './pages/Receipt';
import DeliveryReport from './pages/DeliveryReport';
import BudgetReports from './pages/BudgetReports';
import OrderReports from './pages/OrderReports';
import { Logo } from './components/Logo';
import { AmbientMusic } from './components/AmbientMusic';
import { Home, ArrowLeft } from 'lucide-react';
import { BudgetItem, PaymentMethod, BudgetType } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('main-menu');
  const [previousTab, setPreviousTab] = useState('main-menu');
  const [viewingReceiptId, setViewingReceiptId] = useState<string | null>(null);
  const [editingBudgetId, setEditingBudgetId] = useState<string | null>(null);
  const [orderFilter, setOrderFilter] = useState<any>('ALL');
  const store = useAppState();

  // Persistent Draft Budget State
  const [draftBudgetItems, setDraftBudgetItems] = useState<BudgetItem[]>([]);
  const [draftCustomerId, setDraftCustomerId] = useState('');
  const [draftIsChurchService, setDraftIsChurchService] = useState(false);
  const [draftIsDownPaymentMade, setDraftIsDownPaymentMade] = useState(true);
  const [draftDownPaymentMethod, setDraftDownPaymentMethod] = useState<PaymentMethod>('PIX');
  const [draftDownPaymentValue, setDraftDownPaymentValue] = useState(0);

  // Draft for the item currently being edited/typed in the form
  const [draftCurrentItem, setDraftCurrentItem] = useState({
    theme: '',
    observation: '',
    budgetType: 'LASER' as BudgetType,
    materialId: '',
    width: 0,
    height: 0,
    quantity: 1,
    productionTimeMinutes: 0,
    machineTimeMinutes: 0,
    paintingTimeMinutes: 0,
    assemblyTimeMinutes: 0,
    printingSheets: 0,
    laminationSheets: 0,
    selectedMargin: 2.0,
    isManualPrice: false,
    manualUnitPrice: 0 
  });

  const clearDraft = () => {
    setDraftBudgetItems([]);
    setDraftCustomerId('');
    setDraftIsChurchService(false);
    setDraftIsDownPaymentMade(true);
    setDraftDownPaymentMethod('PIX');
    setDraftDownPaymentValue(0);
    setDraftCurrentItem({
      theme: '',
      observation: '',
      budgetType: 'LASER' as BudgetType,
      materialId: '',
      width: 0,
      height: 0,
      quantity: 1,
      productionTimeMinutes: 0,
      machineTimeMinutes: 0,
      paintingTimeMinutes: 0,
      assemblyTimeMinutes: 0,
      printingSheets: 0,
      laminationSheets: 0,
      selectedMargin: 2.0,
      isManualPrice: false,
      manualUnitPrice: 0 
    });
  };

  const handleNavigate = (tab: string) => {
    setPreviousTab(activeTab);
    if (tab === 'orders-budget') {
      setActiveTab('orders');
      setOrderFilter('BUDGET');
    } else if (tab === 'orders-active') {
      setActiveTab('orders');
      setOrderFilter('ORDER_PENDING');
    } else if (tab === 'orders-delivered') {
      setActiveTab('orders');
      setOrderFilter('ORDER_DELIVERED');
    } else {
      setActiveTab(tab);
    }
  };

  const handleBack = () => {
    setActiveTab(previousTab);
  };

  const handlePrintReceipt = (id: string) => {
    setViewingReceiptId(id);
    setPreviousTab(activeTab);
    setActiveTab('receipt');
  };

  const handleEditBudget = (id: string) => {
    const existing = store.budgets.find(b => b.id === id);
    if (existing) {
        setDraftBudgetItems(existing.items);
        setDraftCustomerId(existing.customerId);
        setDraftIsChurchService(existing.isChurchService || false);
        setDraftIsDownPaymentMade(existing.isDownPaymentMade);
        setDraftDownPaymentMethod(existing.downPaymentMethod || 'PIX');
        setDraftDownPaymentValue(existing.downPaymentValue);
    }
    setEditingBudgetId(id);
    setPreviousTab(activeTab);
    setActiveTab('pricing');
  };

  const handleNewBudget = () => {
    clearDraft();
    setEditingBudgetId(null);
    setPreviousTab(activeTab);
    setActiveTab('pricing');
  };

  const renderContent = () => {
    if (activeTab === 'main-menu') {
      return <MainMenu onNavigate={handleNavigate} />;
    }

    if (viewingReceiptId && activeTab === 'receipt') {
      return <Receipt budgetId={viewingReceiptId} store={store} onBack={() => { setViewingReceiptId(null); setActiveTab(previousTab); }} />;
    }

    const content = (() => {
      switch (activeTab) {
        case 'dashboard': return <Dashboard store={store} onNavigate={handleNavigate} onNewBudget={handleNewBudget} />;
        case 'customers': return <Customers store={store} onBack={handleBack} />;
        case 'materials': return <Materials store={store} onBack={handleBack} />;
        case 'fixed-costs': return <FixedCosts store={store} />;
        case 'pricing': return (
            <BudgetCalculator 
                store={store} 
                editingId={editingBudgetId} 
                onComplete={() => { 
                    setEditingBudgetId(null); 
                    clearDraft();
                    setActiveTab('orders'); 
                }} 
                onNavigate={handleNavigate}
                budgetItems={draftBudgetItems}
                setBudgetItems={setDraftBudgetItems}
                customerId={draftCustomerId}
                setCustomerId={setDraftCustomerId}
                isChurchService={draftIsChurchService}
                setIsChurchService={setDraftIsChurchService}
                isDownPaymentMade={draftIsDownPaymentMade}
                setIsDownPaymentMade={setDraftIsDownPaymentMade}
                downPaymentMethod={draftDownPaymentMethod}
                setDownPaymentMethod={setDraftDownPaymentMethod}
                downPaymentValue={draftDownPaymentValue}
                setDownPaymentValue={setDraftDownPaymentValue}
                currentItem={draftCurrentItem}
                setCurrentItem={setDraftCurrentItem}
            />
        );
        case 'orders': return <Orders store={store} onPrint={handlePrintReceipt} onEdit={handleEditBudget} initialFilter={orderFilter} />;
        case 'deliveries': return <DeliveryReport store={store} />;
        case 'reports-budgets': return <BudgetReports store={store} onNavigate={handleNavigate} onPrint={handlePrintReceipt} />;
        case 'reports-orders': return <OrderReports store={store} />;
        default: return <MainMenu onNavigate={handleNavigate} />;
      }
    })();

    return (
      <div className="space-y-6">
        <header className="flex items-center justify-between mb-8 no-print border-b border-[#C5A059]/10 pb-4">
          <div className="flex gap-2">
            <button 
              onClick={() => handleNavigate('main-menu')}
              className="flex items-center gap-2 bg-[#C5A059] text-white px-4 py-2 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg hover:brightness-110 transition"
            >
              <Home size={18} /> Início
            </button>
            {activeTab !== 'main-menu' && (
               <button 
                onClick={handleBack}
                className="flex items-center gap-2 bg-white text-[#C5A059] border border-[#C5A059]/30 px-4 py-2 rounded-xl font-black text-xs uppercase tracking-widest shadow-sm hover:bg-gray-50 transition"
              >
                <ArrowLeft size={18} /> Voltar
              </button>
            )}
          </div>
          <div className="hidden md:block">
            <h2 className="text-[#C5A059] font-serif tracking-[0.2em] uppercase text-sm">Fábrica de Sonhos</h2>
          </div>
        </header>
        {content}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#F9F7F4]">
      <AmbientMusic />
      <main className={`relative ${activeTab !== 'main-menu' ? 'p-4 md:p-8' : ''}`}>
        <div className={activeTab !== 'main-menu' ? "max-w-7xl mx-auto" : ""}>
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;
