
import { RawMaterial, FixedCostsConfig, PriceValidity } from '../types';

export const getPriceForDate = (material: RawMaterial, dateStr: string): number => {
  const targetDate = new Date(dateStr).getTime();
  const validPrice = material.prices.find(p => {
    const start = new Date(p.startDate).getTime();
    const end = new Date(p.endDate).getTime();
    return targetDate >= start && targetDate <= end;
  });
  return validPrice ? validPrice.value : (material.prices[0]?.value || 0);
};

export const calculateMaterialCostPerSqMm = (material: RawMaterial, dateStr: string): number => {
  if (material.type === 'PAPELARIA') return 0;
  const area = (material.width || 0) * (material.height || 0);
  if (area === 0) return 0;
  const price = getPriceForDate(material, dateStr);
  return price / area;
};

export const calculateHourlyFixedCost = (config: FixedCostsConfig): number => {
  const totalFixed = config.items.reduce((acc, item) => acc + item.value, 0);
  const totalWithSalary = totalFixed + config.desiredSalary;
  return totalWithSalary / config.monthlyHours;
};

export const calculateMinuteFixedCost = (config: FixedCostsConfig): number => {
  return calculateHourlyFixedCost(config) / 60;
};

export const calculateProductMaterialCost = (
  material: RawMaterial,
  width: number,
  height: number,
  quantity: number,
  dateStr: string
): number => {
  const price = getPriceForDate(material, dateStr);
  if (material.type === 'PAPELARIA') {
    return price * quantity;
  }
  const unitArea = width * height;
  const costPerMm2 = calculateMaterialCostPerSqMm(material, dateStr);
  return unitArea * costPerMm2 * quantity;
};

export const calculateLaborCost = (
  config: FixedCostsConfig,
  minutes: number,
  quantity: number
): number => {
  const costPerMinute = calculateMinuteFixedCost(config);
  return costPerMinute * minutes * quantity;
};

export const calculateMachineCostShare = (
  config: FixedCostsConfig,
  machineMinutes: number,
  quantity: number
): number => {
  const costPerMinute = (config.machineHourRate || 0) / 60;
  return costPerMinute * machineMinutes * quantity;
};

// Arredondamento solicitado: finais 00, 10, 20... e acima de 0.90 vira o próximo inteiro.
export const roundSmart = (value: number): number => {
  const integerPart = Math.floor(value);
  const decimalPart = value - integerPart;
  
  if (decimalPart > 0.90) {
    return integerPart + 1;
  }
  
  // Arredonda para o múltiplo de 0.10 mais próximo
  return Math.round(value * 10) / 10;
};

export const PRINT_SHEET_PRICE = 6.00;
export const LAMINATION_SHEET_PRICE = 1.00;

export const calculateAdditionalServicesCost = (
  printingSheets: number,
  laminationSheets: number,
  quantity: number
): number => {
  return (printingSheets * PRINT_SHEET_PRICE + laminationSheets * LAMINATION_SHEET_PRICE) * quantity;
};

export const MARGINS = [
  { label: '10%', value: 1.1 },
  { label: '20%', value: 1.2 },
  { label: '30%', value: 1.3 },
  { label: '40%', value: 1.4 },
  { label: '50%', value: 1.5 },
  { label: '75%', value: 1.75 },
  { label: '100%', value: 2.0 },
  { label: '150%', value: 2.5 },
  { label: '200%', value: 3.0 },
];
