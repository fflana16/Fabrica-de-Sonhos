
import React, { useState, useMemo } from 'react';
import { BudgetStatus, Budget, Customer } from '../types';
import { 
  ClipboardList, CheckCircle2, Truck, User, Search, 
  Filter, Calendar, History, TrendingUp, AlertTriangle, 
  Timer, CheckCircle, AlertCircle, Info, X, Layers, 
  DollarSign, Hash
} from 'lucide-react';

interface Props {
  store: any;
}

const OrderReports: React.FC<Props> = ({ store }) => {
  const budgets = store.budgets as Budget[];
  const customers = store.customers as Customer[];
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'LASER' | 'PAPELARIA'>('ALL');
  const [farolFilter, setFarolFilter] = useState<'ALL' | 'VERDE' | 'AMARELO' | 'LARANJA' | 'VERMELHO'>('ALL');
  const [tab, setTab] = useState<'PENDING' | 'RETRO' | 'EFFECTIVENESS' | 'STATUS_ENTREGA'>('PENDING');
  const [summaryId, setSummaryId] = useState<string | null>(null);

  const pendingOrders = budgets.filter(b => b.status === BudgetStatus.ORDER && !b.isDelivered && !b.isRetroactive);
  const retroOrders = budgets.filter(b => b.isRetroactive);
  const deliveredOrders = budgets.filter(b => b.status === BudgetStatus.ORDER && b.isDelivered && !b.isRetroactive);

  const getDaysRemaining = (dateStr: string | undefined) => {
    if (!dateStr) return null;
    const [y, m, d] = dateStr.split('-').map(Number);
    const delivery = new Date(y, m - 1, d);
    delivery.setHours(0, 0, 0, 0);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = delivery.getTime() - today.getTime();
    return Math.round(diff / (1000 * 60 * 60 * 24));
  };

  const getStatusFromDays = (days: number | null) => {
    if (days === null) return null;
    if (days < 0) return 'VERMELHO';
    if (days <= 1) return 'LARANJA';
    if (days <= 3) return 'AMARELO';
    return 'VERDE';
  };

  const statusConfig = {
    VERMELHO: { color: 'bg-red-500', text: 'Atrasado', icon: <AlertCircle size={14}/> },
    LARANJA: { color: 'bg-orange-500', text: 'Crítico (0-1d)', icon: <Timer size={14}/> },
    AMARELO: { color: 'bg-yellow-500', text: 'Atenção (2-3d)', icon: <Timer size={14}/> },
    VERDE: { color: 'bg-green-500', text: 'Seguro (>3d)', icon: <CheckCircle2 size={14}/> }
  };

  const deliveryStats = useMemo(() => {
    let early = 0;
    let onTime = 0;
    let late = 0;
    
    deliveredOrders.forEach(o => {
        if (!o.deliveryDate || !o.finalPaymentDate) return;
        const [y, m, d] = o.deliveryDate.split('-').map(Number);
        const expectedDate = new Date(y, m - 1, d);
        expectedDate.setHours(0,0,0,0);
        const actualDate = new Date(o.finalPaymentDate);
        actualDate.setHours(0,0,0,0);
        
        if (actualDate < expectedDate) early++;
        else if (actualDate.getTime() === expectedDate.getTime()) onTime++;
        else late++;
    });
    
    return { early, onTime, late, total: early + onTime + late };
  }, [deliveredOrders]);

  const filteredByStatus = useMemo(() => {
    return pendingOrders.map(o => ({
      ...o,
      daysRemaining: getDaysRemaining(o.deliveryDate),
      statusFarol: getStatusFromDays(getDaysRemaining(o.deliveryDate))
    })).filter(o => farolFilter === 'ALL' || o.statusFarol === farolFilter)
       .sort((a, b) => (a.daysRemaining ?? 999) - (b.daysRemaining ?? 999));
  }, [pendingOrders, farolFilter]);

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const summaryBudget = summaryId ? store.budgets.find((b: any) => b.id === summaryId) : null;
  const summaryCustomer = summaryBudget ? store.customers.find((c: any) => c.id === summaryBudget.customerId) : null;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Relatórios de Pedidos & Efetividade</h1>
          <p className="text-gray-500 font-medium tracking-tight">Monitoramento de prazos e produção</p>
        </div>
        
        <div className="flex bg-white p-1 rounded-xl shadow-sm border border-gray-100 overflow-x-auto max-w-full">
            <button onClick={() => setTab('PENDING')} className={`whitespace-nowrap px-4 py-2 text-[10px] font-black uppercase rounded-lg transition ${tab === 'PENDING' ? 'bg-[#C5A059] text-white' : 'text-gray-400'}`}>Pendentes</button>
            <button onClick={() => setTab('STATUS_ENTREGA')} className={`whitespace-nowrap px-4 py-2 text-[10px] font-black uppercase rounded-lg transition ${tab === 'STATUS_ENTREGA' ? 'bg-orange-600 text-white' : 'text-gray-400'}`}>Status Entrega</button>
            <button onClick={() => setTab('RETRO')} className={`whitespace-nowrap px-4 py-2 text-[10px] font-black uppercase rounded-lg transition ${tab === 'RETRO' ? 'bg-indigo-600 text-white' : 'text-gray-400'}`}>Retroativos</button>
            <button onClick={() => setTab('EFFECTIVENESS')} className={`whitespace-nowrap px-4 py-2 text-[10px] font-black uppercase rounded-lg transition ${tab === 'EFFECTIVENESS' ? 'bg-green-600 text-white' : 'text-gray-400'}`}>Efetividade</button>
        </div>
      </header>

      {tab === 'PENDING' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
             <div className="bg-white p-6 rounded-2xl border flex items-center gap-4">
                <div className="p-3 bg-gray-50 text-gray-400 rounded-xl"><ClipboardList/></div>
                <div><p className="text-[10px] font-black text-gray-400 uppercase">Total Ativos</p><p className="text-xl font-black">{pendingOrders.length}</p></div>
             </div>
             <div className="bg-red-50 p-6 rounded-2xl border border-red-100 flex items-center gap-4">
                <div className="p-3 bg-red-100 text-red-600 rounded-xl"><AlertTriangle/></div>
                <div><p className="text-[10px] font-black text-red-600 uppercase">Atrasados</p><p className="text-xl font-black text-red-700">{pendingOrders.filter(o => o.deliveryDate && new Date(o.deliveryDate + 'T12:00:00').getTime() < new Date().setHours(0,0,0,0)).length}</p></div>
             </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 border-b border-gray-50 bg-gray-50/50 flex flex-col md:flex-row justify-between items-center gap-4">
              <h3 className="font-black text-xs uppercase tracking-widest text-[#C5A059] flex items-center gap-2">Produção Ativa</h3>
              <div className="flex gap-2">
                <select className="text-[9px] font-black uppercase bg-white border rounded-lg px-2 py-1 outline-none" value={typeFilter} onChange={e => setTypeFilter(e.target.value as any)}>
                    <option value="ALL">Todos Tipos</option>
                    <option value="LASER">Laser</option>
                    <option value="PAPELARIA">Papelaria</option>
                </select>
              </div>
            </div>
            <table className="w-full text-left">
              <thead className="bg-gray-50/50 text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
                <tr>
                  <th className="px-6 py-4">Pedido / Cliente</th>
                  <th className="px-6 py-4 text-center">Data Entrega</th>
                  <th className="px-6 py-4 text-right">Saldo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {pendingOrders.filter(o => typeFilter === 'ALL' || o.items.some(i => i.budgetType === typeFilter)).map(order => (
                  <tr key={order.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-bold text-gray-900 leading-tight">{order.items[0]?.productName} - {order.items[0]?.theme}</p>
                      <p className="text-[10px] font-black text-[#C5A059] uppercase">{order.orderNumber} • {customers.find(c => c.id === order.customerId)?.name}</p>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex flex-col items-center gap-1 text-[10px] font-black">
                        <Calendar size={12} className="text-indigo-400"/>
                        {order.deliveryDate ? new Date(order.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'N/A'}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-black text-red-600">{formatCurrency(order.remainingValue)}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'STATUS_ENTREGA' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(statusConfig).map(([key, config]) => (
              <button 
                key={key} 
                onClick={() => setFarolFilter(farolFilter === key ? 'ALL' : key as any)}
                className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 ${farolFilter === key ? 'ring-2 ring-offset-2 ring-gray-400 ' + config.color + ' text-white' : 'bg-white text-gray-400 hover:bg-gray-50'}`}
              >
                {config.icon}
                <span className="text-[10px] font-black uppercase">{config.text}</span>
                <span className="text-xl font-black">{pendingOrders.filter(o => getStatusFromDays(getDaysRemaining(o.deliveryDate)) === key).length}</span>
              </button>
            ))}
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-6 border-b bg-gray-50/50 flex justify-between items-center">
               <h3 className="font-black text-xs uppercase tracking-widest text-orange-600">Pedidos Agrupados por Status</h3>
               <button onClick={() => setFarolFilter('ALL')} className="text-[9px] font-black uppercase text-gray-400 hover:text-gray-600">Ver Todos</button>
            </div>
            <table className="w-full text-left">
              <thead className="bg-gray-50/50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                <tr>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Cód / Cliente</th>
                  <th className="px-6 py-4 text-center">Entrega Prevista</th>
                  <th className="px-6 py-4 text-center">Dias Restantes</th>
                  <th className="px-6 py-4 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredByStatus.map(order => {
                  const config = statusConfig[order.statusFarol as keyof typeof statusConfig];
                  return (
                    <tr key={order.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-black text-white uppercase ${config?.color || 'bg-gray-300'}`}>
                          {config?.icon} {config?.text}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-xs font-black text-gray-900">{order.orderNumber}</p>
                        <p className="text-[10px] text-gray-500 uppercase font-bold">{customers.find(c => c.id === order.customerId)?.name}</p>
                      </td>
                      <td className="px-6 py-4 text-center text-xs font-medium text-gray-600">
                        {order.deliveryDate ? new Date(order.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR') : '---'}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`font-black text-sm ${order.daysRemaining !== null && order.daysRemaining < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                          {order.daysRemaining !== null ? (order.daysRemaining < 0 ? `${Math.abs(order.daysRemaining)} atrasado` : order.daysRemaining) : '---'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button onClick={() => setSummaryId(order.id)} className="text-[#C5A059] hover:bg-[#C5A059]/10 p-2 rounded-xl transition" title="Ver Detalhes Técnicos">
                          <Info size={18}/>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Summary com QR Code */}
      {summaryId && summaryBudget && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
           <div className="bg-[#FDFBF7] rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col border border-[#C5A059]/30 max-h-[90vh]">
               <div className="p-6 bg-[#C5A059] text-white flex justify-between items-center">
                   <div className="flex items-center gap-4">
                      <div className="p-1 bg-white rounded-lg">
                        <img 
                          src="https://api.qrserver.com/v1/create-qr-code/?size=50x50&data=https://www.instagram.com/rosiefreire_fabricadesonhos/" 
                          alt="QR Code" 
                          className="w-10 h-10"
                        />
                      </div>
                      <div>
                        <h3 className="font-serif text-xl tracking-widest uppercase">Resumo Técnico</h3>
                        <p className="text-[10px] uppercase font-black opacity-80">{summaryBudget.orderNumber || summaryBudget.code}</p>
                      </div>
                   </div>
                   <button onClick={() => setSummaryId(null)}><X size={24}/></button>
               </div>
               <div className="p-8 overflow-y-auto space-y-8">
                  <section className="grid grid-cols-2 gap-6">
                      <div className="space-y-1">
                          <h4 className="text-[10px] font-black text-[#C5A059] uppercase tracking-widest border-b border-[#C5A059]/10 pb-1 flex items-center gap-2"><User size={12}/> Cliente</h4>
                          <p className="font-black text-gray-900">
                             {summaryCustomer?.name || 'Cliente não encontrado'}
                          </p>
                      </div>
                      <div className="space-y-1 text-right">
                          <h4 className="text-[10px] font-black text-[#C5A059] uppercase tracking-widest border-b border-[#C5A059]/10 pb-1 flex items-center justify-end gap-2"><Calendar size={12}/> Data Entrega</h4>
                          <p className="font-black text-[#C5A059] text-lg">
                            {summaryBudget.deliveryDate ? new Date(summaryBudget.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'Não agendada'}
                          </p>
                      </div>
                  </section>
                  <section className="bg-[#C5A059] p-6 rounded-3xl text-white shadow-xl flex justify-between items-center">
                    <div>
                      <p className="text-[10px] font-black text-white/60 uppercase">Saldo Pendente</p>
                      <p className="text-3xl font-black">{formatCurrency(summaryBudget.remainingValue)}</p>
                    </div>
                  </section>
               </div>
               <div className="p-6 bg-gray-50 border-t">
                   <button onClick={() => setSummaryId(null)} className="w-full py-4 bg-white border-2 border-gray-100 rounded-2xl font-black text-xs uppercase text-gray-400 hover:bg-gray-100 transition tracking-widest">Fechar Detalhes</button>
               </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default OrderReports;
