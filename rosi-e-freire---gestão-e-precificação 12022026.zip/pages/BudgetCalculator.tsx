
import React, { useState, useMemo, useEffect } from 'react';
import { AppState, BudgetStatus, Budget, BudgetItem, PaymentMethod, Customer, BudgetType, FiscalType } from '../types';
import { 
  calculateProductMaterialCost, 
  calculateLaborCost, 
  calculateMachineCostShare, 
  calculateAdditionalServicesCost,
  roundSmart,
  getPriceForDate,
  MARGINS 
} from '../utils/calculations';
import { Ruler, Clock, Package, Calculator, Zap, Scroll, Plus, X, Pencil, Trash2, List, Edit3, Info, Building2, FileCheck, Tag, Church, Calendar, CreditCard, History, PackagePlus, UserPlus } from 'lucide-react';

interface Props {
  store: any;
  editingId: string | null;
  onComplete: () => void;
  onNavigate: (tab: string) => void;
  budgetItems: BudgetItem[];
  setBudgetItems: React.Dispatch<React.SetStateAction<BudgetItem[]>>;
  customerId: string;
  setCustomerId: React.Dispatch<React.SetStateAction<string>>;
  isChurchService: boolean;
  setIsChurchService: React.Dispatch<React.SetStateAction<boolean>>;
  isDownPaymentMade: boolean;
  setIsDownPaymentMade: React.Dispatch<React.SetStateAction<boolean>>;
  downPaymentMethod: PaymentMethod;
  setDownPaymentMethod: React.Dispatch<React.SetStateAction<PaymentMethod>>;
  downPaymentValue: number;
  setDownPaymentValue: React.Dispatch<React.SetStateAction<number>>;
  currentItem: any;
  setCurrentItem: any;
}

const BudgetCalculator: React.FC<Props> = ({ 
  store, 
  editingId, 
  onComplete, 
  onNavigate,
  budgetItems,
  setBudgetItems,
  customerId,
  setCustomerId,
  isChurchService,
  setIsChurchService,
  isDownPaymentMade,
  setIsDownPaymentMade,
  downPaymentMethod,
  setDownPaymentMethod,
  downPaymentValue,
  setDownPaymentValue,
  currentItem,
  setCurrentItem
}) => {
  const [editingItemIdx, setEditingItemIdx] = useState<number | null>(null);
  const [fiscalType, setFiscalType] = useState<FiscalType>('RECIBO');
  const [downPaymentDate, setDownPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [isRetroactive, setIsRetroactive] = useState(false);
  const [retroDate, setRetroDate] = useState(new Date().toISOString().split('T')[0]);
  const [deliveryDate, setDeliveryDate] = useState(new Date().toISOString().split('T')[0]);

  const [fiscalData, setFiscalData] = useState({
    customerTaxId: '',
    customerAddress: '',
    stateRegistration: '',
    receiptObservations: ''
  });

  useEffect(() => {
    if (editingId) {
      const existing = store.budgets.find((b: Budget) => b.id === editingId);
      if (existing) {
        setFiscalType(existing.fiscalType || 'RECIBO');
        setFiscalData({
          customerTaxId: existing.customerTaxId || '',
          customerAddress: existing.customerAddress || '',
          stateRegistration: existing.stateRegistration || '',
          receiptObservations: existing.receiptObservations || ''
        });
        if (existing.downPaymentDate) {
          setDownPaymentDate(existing.downPaymentDate.split('T')[0]);
        }
        if (existing.isRetroactive) {
          setIsRetroactive(true);
          setRetroDate(existing.createdAt.split('T')[0]);
        }
        if (existing.deliveryDate) {
          setDeliveryDate(existing.deliveryDate);
        }
      }
    }
  }, [editingId, store.budgets]);

  const selectedMaterialInfo = useMemo(() => {
    return store.materials.find((m: any) => m.id === currentItem.materialId);
  }, [currentItem.materialId, store.materials]);

  const calculation = useMemo(() => {
    if (!currentItem.materialId) return null;
    const material = selectedMaterialInfo;
    if (!material) return null;

    const isPaper = currentItem.budgetType === 'PAPELARIA';
    const referenceDate = isRetroactive ? new Date(retroDate + 'T12:00:00').toISOString() : new Date().toISOString();
    
    const matCost = calculateProductMaterialCost(material, currentItem.width, currentItem.height, currentItem.quantity, referenceDate);
    
    let finalUnitPrice: number;

    if (isPaper) {
      finalUnitPrice = getPriceForDate(material, referenceDate);
      if (currentItem.isManualPrice && currentItem.manualUnitPrice > 0) {
        finalUnitPrice = currentItem.manualUnitPrice;
      }
    } else {
      const prodTime = currentItem.productionTimeMinutes;
      const machineTime = currentItem.machineTimeMinutes;
      const paintTime = currentItem.paintingTimeMinutes;
      const assemblyTime = currentItem.assemblyTimeMinutes;
      const totalMinutes = prodTime + paintTime + assemblyTime;
      
      const fixedShare = calculateLaborCost(store.fixedCosts, totalMinutes, currentItem.quantity);
      const machineCost = calculateMachineCostShare(store.fixedCosts, machineTime, currentItem.quantity);
      const totalBaseCost = matCost + fixedShare + machineCost;
      
      let unitPrice = totalBaseCost / currentItem.quantity;
      if (currentItem.isManualPrice && currentItem.manualUnitPrice > 0) {
        unitPrice = currentItem.manualUnitPrice;
      } else {
        unitPrice = unitPrice * currentItem.selectedMargin;
      }
      finalUnitPrice = roundSmart(unitPrice);
    }

    const finalPrice = finalUnitPrice * currentItem.quantity;
    
    return { 
      matCost, 
      totalBaseCost: isPaper ? matCost : (matCost / currentItem.quantity),
      finalPrice, 
      finalUnitPrice 
    };
  }, [currentItem, store.fixedCosts, selectedMaterialInfo, isRetroactive, retroDate]);

  const totals = useMemo(() => {
    const totalBase = budgetItems.reduce((acc, item) => acc + item.totalBaseCost, 0);
    const totalFinal = budgetItems.reduce((acc, item) => acc + item.finalPrice, 0);
    return { totalBase, totalFinal };
  }, [budgetItems]);

  const addOrUpdateItem = () => {
    if (!calculation || !selectedMaterialInfo) return;
    const itemData: BudgetItem = {
      ...currentItem,
      id: editingItemIdx !== null ? budgetItems[editingItemIdx].id : crypto.randomUUID(),
      productName: selectedMaterialInfo.name,
      materialCost: calculation.matCost,
      fixedCostApportionment: 0,
      machineCost: 0,
      serviceCost: 0,
      totalBaseCost: calculation.totalBaseCost,
      finalPrice: calculation.finalPrice,
      manualUnitPrice: currentItem.isManualPrice ? currentItem.manualUnitPrice : undefined
    };

    if (editingItemIdx !== null) {
      const newItems = [...budgetItems];
      newItems[editingItemIdx] = itemData;
      setBudgetItems(newItems);
      setEditingItemIdx(null);
    } else {
      setBudgetItems([...budgetItems, itemData]);
    }

    setCurrentItem({
      ...currentItem, theme: '', observation: '', width: 0, height: 0, quantity: 1,
      productionTimeMinutes: 0, machineTimeMinutes: 0, paintingTimeMinutes: 0,
      assemblyTimeMinutes: 0, isManualPrice: false, manualUnitPrice: 0
    });
  };

  const startEditItem = (idx: number) => {
    const item = budgetItems[idx];
    setEditingItemIdx(idx);
    setCurrentItem({
      theme: item.theme, observation: item.observation, budgetType: item.budgetType,
      materialId: item.materialId, width: item.width, height: item.height,
      quantity: item.quantity, productionTimeMinutes: item.productionTimeMinutes,
      machineTimeMinutes: item.machineTimeMinutes, paintingTimeMinutes: item.paintingTimeMinutes,
      assemblyTimeMinutes: item.assemblyTimeMinutes, printingSheets: item.printingSheets,
      laminationSheets: item.laminationSheets, selectedMargin: item.selectedMargin,
      isManualPrice: item.isManualPrice || false,
      manualUnitPrice: item.manualUnitPrice || (item.finalPrice / (item.quantity || 1))
    });
  };

  const removeBudgetItem = (id: string) => {
    setBudgetItems(budgetItems.filter(item => item.id !== id));
    if (editingItemIdx !== null && budgetItems[editingItemIdx]?.id === id) setEditingItemIdx(null);
  };

  const handleSubmit = () => {
    if (budgetItems.length === 0 || !customerId) return;
    const budgetData = {
      customerId,
      items: budgetItems,
      totalBaseCost: totals.totalBase,
      totalFinalPrice: totals.totalFinal,
      fiscalType,
      ...fiscalData,
      isDownPaymentMade,
      isZeroDownPaymentRisk: isDownPaymentMade && downPaymentValue === 0,
      downPaymentMethod,
      downPaymentValue,
      downPaymentPercent: (downPaymentValue / (totals.totalFinal || 1)) * 100,
      downPaymentDate: isDownPaymentMade ? new Date(downPaymentDate + 'T12:00:00').toISOString() : undefined,
      remainingValue: totals.totalFinal - downPaymentValue,
      isChurchService,
      status: isRetroactive ? BudgetStatus.ORDER : BudgetStatus.BUDGET,
      isRetroactive,
      createdAt: isRetroactive ? new Date(retroDate + 'T12:00:00').toISOString() : new Date().toISOString(),
      deliveryDate: isRetroactive ? deliveryDate : undefined
    };
    if (editingId) store.updateBudget(editingId, budgetData);
    else store.addBudget(budgetData);
    onComplete();
  };

  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  const filteredMaterials = store.materials.filter((m: any) => m.type === currentItem.budgetType);

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{editingId ? 'Modificar Orçamento' : (isRetroactive ? 'Novo Pedido Retroativo' : 'Novo Orçamento')}</h1>
          <p className="text-gray-500 font-medium tracking-tight">Criação de proposta ou lançamento de vendas passadas</p>
        </div>
        <div className="flex flex-wrap gap-2">
           <button 
             onClick={() => setIsRetroactive(!isRetroactive)} 
             className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all border shadow-sm ${isRetroactive ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-white text-indigo-600 border-indigo-100 hover:bg-indigo-50'}`}
           >
             <History size={14}/> {isRetroactive ? 'Modo Retroativo Ativado' : 'Cadastrar Pedido Retroativo'}
           </button>
           <div className="flex bg-[#F0E6D2] p-1 rounded-2xl border border-[#C5A059]/10 shadow-sm">
              <button onClick={() => setCurrentItem({...currentItem, budgetType: 'LASER', materialId: '', isManualPrice: false})} className={`flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black transition-all ${currentItem.budgetType === 'LASER' ? 'bg-[#C5A059] text-white' : 'text-[#8B7355]'}`}><Zap size={14}/> LASER</button>
              <button onClick={() => setCurrentItem({...currentItem, budgetType: 'PAPELARIA', materialId: '', isManualPrice: false})} className={`flex items-center gap-2 px-6 py-2 rounded-xl text-xs font-black transition-all ${currentItem.budgetType === 'PAPELARIA' ? 'bg-[#C5A059] text-white' : 'text-[#8B7355]'}`}><Scroll size={14}/> PAPELARIA</button>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 space-y-4">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="flex-1">
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Cliente</label>
                <div className="flex gap-2">
                  <select className="flex-1 border-2 border-gray-100 rounded-xl px-4 py-2 bg-white outline-none" value={customerId} onChange={e => setCustomerId(e.target.value)}>
                    <option value="">Selecionar Cliente...</option>
                    {store.customers.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                  <button 
                    onClick={() => onNavigate('customers')}
                    className="px-4 py-2 bg-white border-2 border-[#C5A059]/30 text-[#C5A059] rounded-xl text-[10px] font-black uppercase hover:bg-[#C5A059]/5 transition flex items-center gap-2"
                    title="Cadastrar novo cliente sem perder o rascunho"
                  >
                    <UserPlus size={16}/> Novo
                  </button>
                </div>
              </div>
              <label className="flex items-center gap-2 text-[10px] font-black text-indigo-600 bg-indigo-50 px-4 py-3 rounded-xl cursor-pointer self-stretch md:self-auto"><input type="checkbox" checked={isChurchService} onChange={e => setIsChurchService(e.target.checked)} className="w-4 h-4 accent-indigo-600 rounded"/><Church size={14}/> IGREJA</label>
            </div>

            {isRetroactive && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in slide-in-from-top-2">
                 <div>
                   <label className="block text-[10px] font-black text-indigo-400 uppercase mb-1">Data Original do Pedido</label>
                   <input type="date" className="w-full border-2 border-indigo-100 rounded-xl px-4 py-2" value={retroDate} onChange={e => setRetroDate(e.target.value)} />
                 </div>
                 <div>
                   <label className="block text-[10px] font-black text-indigo-400 uppercase mb-1">Data da Entrega</label>
                   <input type="date" className="w-full border-2 border-indigo-100 rounded-xl px-4 py-2" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} />
                 </div>
              </div>
            )}
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 space-y-4">
             <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-black text-[#C5A059] uppercase tracking-widest flex items-center gap-2"><FileCheck size={18}/> Documentação</h3>
                <div className="flex bg-gray-50 p-1 rounded-xl">
                    <button onClick={() => setFiscalType('RECIBO')} className={`px-4 py-1 text-[10px] font-black uppercase rounded-lg transition ${fiscalType === 'RECIBO' ? 'bg-gray-200 text-gray-800' : 'text-gray-400'}`}>Recibo</button>
                    <button onClick={() => setFiscalType('NF')} className={`px-4 py-1 text-[10px] font-black uppercase rounded-lg transition ${fiscalType === 'NF' ? 'bg-indigo-600 text-white' : 'text-gray-400'}`}>NF</button>
                </div>
             </div>
             {fiscalType === 'NF' ? (
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in">
                  <input className="border rounded-xl px-4 py-2" value={fiscalData.customerTaxId} onChange={e => setFiscalData({...fiscalData, customerTaxId: e.target.value})} placeholder="CNPJ / CPF" />
                  <input className="border rounded-xl px-4 py-2" value={fiscalData.stateRegistration} onChange={e => setFiscalData({...fiscalData, stateRegistration: e.target.value})} placeholder="Insc. Estadual" />
                  <input className="col-span-full border rounded-xl px-4 py-2" value={fiscalData.customerAddress} onChange={e => setFiscalData({...fiscalData, customerAddress: e.target.value})} placeholder="Endereço Completo" />
               </div>
             ) : (
               <input className="w-full border rounded-xl px-4 py-2" value={fiscalData.receiptObservations} onChange={e => setFiscalData({...fiscalData, receiptObservations: e.target.value})} placeholder="Dados / Obs p/ Recibo" />
             )}
          </div>

          <div className={`bg-white p-6 rounded-xl shadow-sm border-2 ${editingItemIdx !== null ? 'border-[#C5A059]' : 'border-gray-100'} space-y-4`}>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-[#C5A059] uppercase tracking-widest flex items-center gap-2"><Plus size={18}/> {editingItemIdx !== null ? 'Modificar Item' : 'Inserir Novo Item'}</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="col-span-full"><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Nome do Produto / Tema</label><input className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" value={currentItem.theme} onChange={e => setCurrentItem({...currentItem, theme: e.target.value})} placeholder="Ex: Placa MDF Nome" /></div>
              
              <div className="col-span-full flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Material Base</label>
                  <select className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 bg-white" value={currentItem.materialId} onChange={e => setCurrentItem({...currentItem, materialId: e.target.value})}>
                    <option value="">Escolher...</option>
                    {filteredMaterials.map((m: any) => <option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                </div>
                <div className="flex items-end">
                   <button 
                    onClick={() => onNavigate('materials')}
                    className="h-[46px] flex items-center gap-2 bg-white border-2 border-[#C5A059]/30 text-[#C5A059] px-4 py-2 rounded-xl text-[10px] font-black uppercase hover:bg-[#C5A059]/5 transition"
                    title="Cadastrar novo material sem perder o rascunho"
                   >
                     <PackagePlus size={16}/> Novo Material
                   </button>
                </div>
              </div>

              <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Quantidade</label><input type="number" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" value={currentItem.quantity || ''} onChange={e => setCurrentItem({...currentItem, quantity: Number(e.target.value)})} /></div>
              <div className="col-span-full"><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Observações do Item</label><input className="w-full border-2 border-gray-100 rounded-xl px-4 py-2" value={currentItem.observation} onChange={e => setCurrentItem({...currentItem, observation: e.target.value})} /></div>
            </div>

            {currentItem.budgetType === 'LASER' ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Largura (mm)</label><input type="number" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2" value={currentItem.width || ''} onChange={e => setCurrentItem({...currentItem, width: Number(e.target.value)})}/></div>
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Altura (mm)</label><input type="number" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2" value={currentItem.height || ''} onChange={e => setCurrentItem({...currentItem, height: Number(e.target.value)})}/></div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Tempo Máquina (min)</label><input type="number" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2" value={currentItem.machineTimeMinutes || ''} onChange={e => setCurrentItem({...currentItem, machineTimeMinutes: Number(e.target.value)})}/></div>
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Tempo Pintura (min)</label><input type="number" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2" value={currentItem.paintingTimeMinutes || ''} onChange={e => setCurrentItem({...currentItem, paintingTimeMinutes: Number(e.target.value)})}/></div>
                  <div><label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Tempo Montagem (min)</label><input type="number" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2" value={currentItem.assemblyTimeMinutes || ''} onChange={e => setCurrentItem({...currentItem, assemblyTimeMinutes: Number(e.target.value)})}/></div>
                </div>
                <div className="pt-4 flex flex-wrap gap-2 justify-center">
                  {MARGINS.map(m => (
                    <button key={m.value} onClick={() => setCurrentItem({...currentItem, selectedMargin: m.value})} className={`px-4 py-1.5 rounded-lg text-[10px] font-black transition ${currentItem.selectedMargin === m.value ? 'bg-[#C5A059] text-white' : 'bg-gray-100 text-gray-400'}`}>{m.label}</button>
                  ))}
                  <button onClick={() => setCurrentItem({...currentItem, isManualPrice: !currentItem.isManualPrice, manualUnitPrice: calculation?.finalUnitPrice || 0})} className={`px-4 py-1.5 rounded-lg text-[10px] font-black border flex items-center gap-1 ${currentItem.isManualPrice ? 'bg-indigo-600 text-white' : 'text-indigo-600 border-indigo-100'}`}><Edit3 size={12}/> Manual</button>
                </div>
              </>
            ) : (
              <div className="pt-4">
                 <button onClick={() => setCurrentItem({...currentItem, isManualPrice: !currentItem.isManualPrice, manualUnitPrice: calculation?.finalUnitPrice || 0})} className={`px-4 py-2 rounded-xl text-[10px] font-black border flex items-center gap-1 ${currentItem.isManualPrice ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-indigo-600 border-indigo-100'}`}>
                    <Edit3 size={14}/> {currentItem.isManualPrice ? 'Desativar Ajuste Manual' : 'Ajustar Valor de Venda Manualmente'}
                 </button>
                 <p className="text-[10px] text-gray-400 font-bold mt-2 italic">*Papelaria: Valor de venda sugerido é igual ao custo do material.</p>
              </div>
            )}

            {(currentItem.isManualPrice) && (
              <div className="bg-indigo-50 p-6 rounded-2xl border-2 border-indigo-100 animate-in slide-in-from-bottom-2 mt-4">
                 <label className="block text-[10px] font-black text-indigo-400 uppercase mb-2">Ajuste de Valor UNITÁRIO de Venda</label>
                 <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-400 font-black">R$</span>
                    <input type="number" step="0.01" className="w-full border-2 border-indigo-200 rounded-xl pl-10 pr-4 py-3 bg-white font-black text-indigo-900 text-lg outline-none" value={currentItem.manualUnitPrice || ''} onChange={e => setCurrentItem({...currentItem, manualUnitPrice: Number(e.target.value)})} placeholder="0,00" />
                 </div>
              </div>
            )}

            <button onClick={addOrUpdateItem} disabled={!calculation || !currentItem.theme} className="w-full bg-[#C5A059] text-white py-4 rounded-2xl font-black text-sm uppercase shadow-xl hover:brightness-110 transition flex items-center justify-center gap-2 mt-6">
              <Plus size={20}/> {editingItemIdx !== null ? 'Modificar Item na Lista' : 'Inserir Item no Orçamento'}
            </button>
          </div>

          {budgetItems.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
               <div className="bg-gray-50 px-6 py-3 border-b border-gray-100 font-black text-[10px] text-gray-400 uppercase"><List size={14} className="inline mr-2"/> Itens Inseridos</div>
               <div className="divide-y divide-gray-50">
                  {budgetItems.map((item, idx) => (
                    <div key={item.id} className="p-4 flex items-center justify-between hover:bg-gray-50 transition">
                       <div>
                          <p className="font-bold text-gray-900 text-sm">{item.theme || item.productName}</p>
                          <p className="text-[9px] font-black text-gray-400 uppercase tracking-tighter">{item.quantity} un • {item.budgetType} • Unit: {formatCurrency(item.finalPrice / item.quantity)}</p>
                       </div>
                       <div className="flex items-center gap-2">
                          <p className="font-black text-gray-900 mr-4">{formatCurrency(item.finalPrice)}</p>
                          <button onClick={() => startEditItem(idx)} className="p-2 text-gray-300 hover:text-indigo-600"><Pencil size={18}/></button>
                          <button onClick={() => removeBudgetItem(item.id)} className="p-2 text-gray-300 hover:text-red-500"><Trash2 size={18}/></button>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
           {calculation && (
             <div className="bg-white p-6 rounded-3xl shadow-xl border-2 border-indigo-100 animate-in slide-in-from-right-4">
                <h3 className="text-xs font-black text-indigo-600 uppercase tracking-widest mb-4 flex items-center gap-2"><Calculator size={16}/> Resumo do Item Atual</h3>
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-400 font-medium">Custo Material {isRetroactive ? 'em ' + new Date(retroDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'Vigente'}</span>
                    <span className="font-bold text-gray-700">{formatCurrency(calculation.matCost)}</span>
                  </div>
                </div>
                <div className="bg-indigo-600 p-5 rounded-2xl text-white shadow-lg text-center">
                  <p className="text-[10px] font-black uppercase opacity-70 tracking-widest mb-1">Preço Venda Unitário</p>
                  <div className="text-2xl font-black">{formatCurrency(calculation.finalUnitPrice)}</div>
                  <div className="mt-2 pt-2 border-t border-white/20">
                    <p className="text-[10px] font-black uppercase opacity-70 tracking-widest mb-1">Total do Item</p>
                    <div className="text-xl font-black">{formatCurrency(calculation.finalPrice)}</div>
                  </div>
                </div>
                <p className="text-[9px] text-indigo-400 font-bold mt-4 text-center uppercase tracking-tight">*Preços baseados na vigência {isRetroactive ? 'da data original informada' : 'atual do material'}.</p>
             </div>
           )}

           <div className="bg-[#FDFBF7] p-8 rounded-3xl shadow-xl border border-[#C5A059]/30 sticky top-8">
              <h3 className="font-serif text-xl text-[#C5A059] uppercase tracking-widest mb-6 border-b border-[#C5A059]/20 pb-4">{isRetroactive ? 'Dados do Pedido' : 'Total do Orçamento'}</h3>
              <div className="space-y-4 mb-8">
                 <div className="bg-[#C5A059] p-6 rounded-2xl text-white shadow-lg text-center">
                    <span className="text-[10px] font-black uppercase opacity-70 tracking-widest">Valor Final {isRetroactive ? 'Vendido' : 'a Cobrar'}</span>
                    <div className="text-3xl font-black">{formatCurrency(totals.totalFinal)}</div>
                 </div>
              </div>
              <div className="space-y-4 border-t border-[#C5A059]/20 pt-6">
                 <label className="flex items-center gap-2 text-xs font-black text-[#8B7355] cursor-pointer"><input type="checkbox" checked={isDownPaymentMade} onChange={e => setIsDownPaymentMade(e.target.checked)} className="w-5 h-5 accent-[#C5A059] rounded" />Registrar Entrada?</label>
                 {isDownPaymentMade && (
                    <div className="space-y-4 mt-4 animate-in fade-in">
                      <div className="relative">
                        <label className="block text-[10px] font-black text-[#C5A059] uppercase mb-1">Valor da Entrada</label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-[#C5A059] text-xs">R$</span>
                          <input type="number" className="w-full border-2 border-[#C5A059]/20 rounded-xl pl-8 pr-4 py-2 font-black text-gray-800" value={downPaymentValue || ''} onChange={e => setDownPaymentValue(Number(e.target.value))} />
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-[#C5A059] uppercase mb-1">Data da Entrada</label>
                        <div className="relative">
                          <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#C5A059]" />
                          <input type="date" className="w-full border-2 border-[#C5A059]/20 rounded-xl pl-9 pr-4 py-2 font-black text-gray-800" value={downPaymentDate} onChange={e => setDownPaymentDate(e.target.value)} />
                        </div>
                      </div>
                      <div>
                        <label className="block text-[10px] font-black text-[#C5A059] uppercase mb-1">Forma de Pagamento (Entrada)</label>
                        <div className="relative">
                          <CreditCard size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#C5A059]" />
                          <select className="w-full border-2 border-[#C5A059]/20 rounded-xl pl-9 pr-4 py-2 font-black text-gray-800 bg-white" value={downPaymentMethod} onChange={e => setDownPaymentMethod(e.target.value as PaymentMethod)}>
                            <option value="PIX">PIX</option>
                            <option value="Dinheiro">Dinheiro</option>
                            <option value="Débito">Débito</option>
                            <option value="Crédito">Crédito</option>
                          </select>
                        </div>
                      </div>
                    </div>
                 )}
              </div>
              <button onClick={handleSubmit} disabled={budgetItems.length === 0 || !customerId} className={`w-full ${isRetroactive ? 'bg-indigo-600' : 'bg-[#C5A059]'} text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-2xl mt-8 hover:brightness-110 disabled:opacity-40 transition transform active:scale-95`}>
                {isRetroactive ? 'Salvar Pedido Retroativo' : 'Salvar Orçamento'}
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetCalculator;
