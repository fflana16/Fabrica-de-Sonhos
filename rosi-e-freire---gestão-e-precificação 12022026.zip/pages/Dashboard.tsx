
import React, { useMemo, useState } from 'react';
import { AppState, BudgetStatus, Budget } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, Legend } from 'recharts';
import { 
  FileText, ShoppingBag, ArrowUpRight, Wallet, 
  DollarSign, BarChart3, History
} from 'lucide-react';

interface Props {
  store: AppState;
  onNavigate: (tab: string) => void;
  onNewBudget: () => void;
}

const Dashboard: React.FC<Props> = ({ store, onNavigate, onNewBudget }) => {
  const [viewType, setViewType] = useState<'MONTHLY' | 'ANNUAL'>('MONTHLY');
  const [filterMonth, setFilterMonth] = useState<number>(new Date().getMonth());
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());

  const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  const years = useMemo(() => {
    const current = new Date().getFullYear();
    const list = [];
    for (let i = 2024; i <= current; i++) list.push(i);
    return list;
  }, []);

  const stats = useMemo(() => {
    const checkPeriod = (dateStr: string | undefined) => {
      if (!dateStr) return false;
      const d = new Date(dateStr);
      if (viewType === 'ANNUAL') return d.getFullYear() === filterYear;
      return d.getMonth() === filterMonth && d.getFullYear() === filterYear;
    };

    // Orçamentos no Período (Exclui retroativos pois eles não passaram por orçamento no sistema)
    const budgetsInPeriod = store.budgets.filter(b => checkPeriod(b.createdAt) && !b.isRetroactive);
    const totalBudgets = budgetsInPeriod.length;
    const totalBudgetItems = budgetsInPeriod.reduce((acc, b) => acc + b.items.length, 0);

    // Pedidos no Período (Apenas os que vieram de orçamento)
    const ordersInPeriod = store.budgets.filter(b => b.status === BudgetStatus.ORDER && checkPeriod(b.orderDate || b.createdAt) && !b.isRetroactive);
    const totalOrders = ordersInPeriod.length;
    const totalOrderItems = ordersInPeriod.reduce((acc, b) => acc + b.items.length, 0);

    // Pedidos Retroativos
    const retroOrders = store.budgets.filter(b => b.isRetroactive && checkPeriod(b.createdAt));
    const totalRetro = retroOrders.length;

    // Financeiro (Inclui todos os recebimentos no período selecionado)
    const downPayments = store.budgets.reduce((acc, b) => (b.isDownPaymentMade && checkPeriod(b.downPaymentDate)) ? acc + (b.downPaymentValue || 0) : acc, 0);
    const finalPayments = store.budgets.reduce((acc, b) => (b.isPaidRemaining && checkPeriod(b.finalPaymentDate)) ? acc + (b.remainingValue || 0) : acc, 0);
    const totalRevenue = downPayments + finalPayments;

    return { totalBudgets, totalBudgetItems, totalOrders, totalOrderItems, totalRetro, downPayments, finalPayments, totalRevenue };
  }, [store.budgets, filterMonth, filterYear, viewType]);

  const chartData = [
    { name: 'Orçamentos', qtd: stats.totalBudgets, itens: stats.totalBudgetItems },
    { name: 'Pedidos (Conv)', qtd: stats.totalOrders, itens: stats.totalOrderItems },
    { name: 'Retroativos', qtd: stats.totalRetro, itens: stats.totalRetro },
  ];

  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Painel de Análise</h1>
          <p className="text-gray-500 font-medium tracking-tight">Estatísticas de vendas, orçamentos e lançamentos retroativos</p>
        </div>
        <div className="flex flex-wrap gap-2 items-center bg-white p-1 rounded-2xl shadow-sm border border-[#C5A059]/10">
          <div className="flex p-1 bg-gray-50 rounded-xl mr-2">
            <button onClick={() => setViewType('MONTHLY')} className={`px-4 py-1.5 text-[10px] font-black uppercase rounded-lg transition ${viewType === 'MONTHLY' ? 'bg-[#C5A059] text-white shadow-md' : 'text-gray-400'}`}>Mensal</button>
            <button onClick={() => setViewType('ANNUAL')} className={`px-4 py-1.5 text-[10px] font-black uppercase rounded-lg transition ${viewType === 'ANNUAL' ? 'bg-[#C5A059] text-white shadow-md' : 'text-gray-400'}`}>Anual</button>
          </div>
          {viewType === 'MONTHLY' && (
            <select className="text-xs font-black uppercase px-3 py-1.5 rounded-lg outline-none bg-transparent text-[#8B7355]" value={filterMonth} onChange={e => setFilterMonth(parseInt(e.target.value))}>
              {months.map((m, i) => <option key={m} value={i}>{m}</option>)}
            </select>
          )}
          <select className="text-xs font-black uppercase px-3 py-1.5 rounded-lg outline-none bg-transparent text-[#8B7355]" value={filterYear} onChange={e => setFilterYear(parseInt(e.target.value))}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard icon={<FileText size={20}/>} label="Orçamentos Novos" value={stats.totalBudgets} subValue={`${stats.totalBudgetItems} tipos materiais`} color="blue" />
        <MetricCard icon={<ShoppingBag size={20}/>} label="Pedidos Convertidos" value={stats.totalOrders} subValue={`${stats.totalOrderItems} tipos materiais`} color="green" />
        <MetricCard icon={<History size={20}/>} label="Lançamentos Retro" value={stats.totalRetro} subValue="Vendas já efetuadas" color="amber" />
        <MetricCard icon={<Wallet size={20}/>} label="Faturamento Total" value={formatCurrency(stats.totalRevenue)} subValue={`Entradas + Saldos`} color="indigo" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-3xl shadow-xl border border-gray-100 flex flex-col">
          <h3 className="text-xs font-black text-[#C5A059] uppercase tracking-[0.2em] mb-6 flex items-center gap-2"><BarChart3 size={16}/> Performance de Vendas</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#999' }} />
                <YAxis hide />
                <Tooltip cursor={{ fill: '#f8f8f8' }} contentStyle={{ borderRadius: '15px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 800 }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 900, textTransform: 'uppercase' }} />
                <Bar dataKey="qtd" name="Qtd Pedidos" radius={[10, 10, 0, 0]}><Cell fill="#C5A059" /><Cell fill="#8B7355" /><Cell fill="#6366f1" /></Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-xl border border-gray-100 flex flex-col">
          <h3 className="text-xs font-black text-[#C5A059] uppercase tracking-[0.2em] mb-6 flex items-center gap-2"><DollarSign size={16}/> Recebimentos no Período</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
             <div className="bg-green-50 p-4 rounded-2xl border border-green-100">
                <p className="text-[9px] font-black text-green-800 uppercase tracking-widest mb-1">Entradas (Sinal)</p>
                <p className="text-xl font-black text-green-900">{formatCurrency(stats.downPayments)}</p>
             </div>
             <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100">
                <p className="text-[9px] font-black text-indigo-800 uppercase tracking-widest mb-1">Saldos Finais</p>
                <p className="text-xl font-black text-indigo-900">{formatCurrency(stats.finalPayments)}</p>
             </div>
          </div>
          <div className="flex-1 flex flex-col justify-center border-t border-gray-50 pt-6">
             <div className="flex justify-between items-center mb-2">
                <span className="text-[10px] font-black text-gray-400 uppercase">Total Recebido</span>
                <span className="text-lg font-black text-[#C5A059]">{formatCurrency(stats.totalRevenue)}</span>
             </div>
             <div className="w-full h-4 bg-gray-100 rounded-full overflow-hidden flex">
                <div className="h-full bg-green-500" style={{ width: `${stats.totalRevenue > 0 ? (stats.downPayments/stats.totalRevenue)*100 : 0}%` }} />
                <div className="h-full bg-indigo-500" style={{ width: `${stats.totalRevenue > 0 ? (stats.finalPayments/stats.totalRevenue)*100 : 0}%` }} />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({ icon, label, value, subValue, color }: any) => {
  const colors: any = { blue: 'bg-blue-50 text-blue-600', green: 'bg-green-50 text-green-600', amber: 'bg-amber-50 text-amber-600', indigo: 'bg-indigo-50 text-indigo-600' };
  return (
    <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-start gap-4">
      <div className={`p-3 rounded-2xl ${colors[color]}`}>{icon}</div>
      <div className="space-y-1">
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{label}</p>
        <p className="text-xl font-black text-gray-900 leading-none">{value}</p>
        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">{subValue}</p>
      </div>
    </div>
  );
};

export default Dashboard;
