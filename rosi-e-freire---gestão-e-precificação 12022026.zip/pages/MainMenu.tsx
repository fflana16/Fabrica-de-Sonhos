
import React from 'react';
import { Logo } from '../components/Logo';
import { 
  LayoutDashboard, Users, Package, Settings, 
  Calculator, FileText, ClipboardList, CheckCircle2,
  PieChart, BarChart3
} from 'lucide-react';

interface Props {
  onNavigate: (tab: string) => void;
}

const MainMenu: React.FC<Props> = ({ onNavigate }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard de Análise', icon: LayoutDashboard },
    { id: 'customers', label: 'Cadastro de Clientes', icon: Users },
    { id: 'materials', label: 'Cadastro de Matérias Primas', icon: Package },
    { id: 'fixed-costs', label: 'Relação de Custos Fixos', icon: Settings },
    { id: 'pricing', label: 'Criar Orçamento', icon: Calculator },
    { id: 'orders-budget', label: 'Exibir Orçamentos', icon: FileText },
    { id: 'orders-active', label: 'Exibir Lista de Pedidos', icon: ClipboardList },
    { id: 'orders-delivered', label: 'Pedidos Entregues', icon: CheckCircle2 },
    { id: 'reports-budgets', label: 'Relatórios de Orçamentos', icon: PieChart },
    { id: 'reports-orders', label: 'Relatórios de Pedidos', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-[#F9F7F4] flex flex-col items-center justify-center p-6 animate-in fade-in duration-1000">
      <div className="mb-10 transform scale-110">
        <Logo />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 w-full max-w-7xl">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className="bg-[#C5A059] group relative overflow-hidden text-white p-6 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1.5 flex flex-col items-center justify-center gap-3 border border-white/10"
          >
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors" />
            <item.icon size={32} strokeWidth={2} className="group-hover:scale-110 transition-transform" />
            <span className="text-[11px] font-black uppercase tracking-widest text-center leading-tight">
              {item.label}
            </span>
          </button>
        ))}
      </div>

      <footer className="mt-12 text-center text-[#C5A059]/40 text-[9px] font-bold uppercase tracking-[0.4em]">
        Rosi e Freire Fábrica de Sonhos • Gestão de Excelência
      </footer>
    </div>
  );
};

export default MainMenu;
