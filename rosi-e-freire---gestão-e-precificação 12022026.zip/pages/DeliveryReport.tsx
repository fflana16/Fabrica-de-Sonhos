
import React, { useState } from 'react';
import { AppState, BudgetStatus, Budget } from '../types';
import { Truck, Calendar, User, Phone, Info, X, Ruler, Clock, Printer, Layers, Banknote, AlertTriangle, Timer } from 'lucide-react';

interface Props {
  store: AppState;
}

const DeliveryReport: React.FC<Props> = ({ store }) => {
  const [selectedBudgetId, setSelectedBudgetId] = useState<string | null>(null);

  const getDaysRemaining = (dateStr: string | undefined) => {
    if (!dateStr) return null;
    
    // Decompõe a string YYYY-MM-DD para garantir a criação da data no horário local
    const [year, month, day] = dateStr.split('-').map(Number);
    const delivery = new Date(year, month - 1, day);
    delivery.setHours(0, 0, 0, 0);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const diffTime = delivery.getTime() - today.getTime();
    // Usa Math.round para evitar imprecisões decimais de horário de verão ou segundos
    return Math.round(diffTime / (1000 * 60 * 60 * 24));
  };

  const getStatusColor = (days: number | null) => {
    if (days === null) return 'text-gray-400 bg-gray-100';
    if (days < 0) return 'text-red-700 bg-red-100 border-red-200';
    if (days >= 0 && days < 2) return 'text-orange-700 bg-orange-100 border-orange-200';
    if (days >= 2 && days <= 3) return 'text-yellow-700 bg-yellow-100 border-yellow-200';
    return 'text-green-700 bg-green-100 border-green-200';
  };

  const getStatusLabel = (days: number | null) => {
    if (days === null) return 'Sem data';
    if (days < 0) return 'Atrasado';
    if (days === 0) return 'Entrega Hoje';
    if (days === 1) return 'Falta 1 dia';
    return `Faltam ${days} dias`;
  };

  const pendingDeliveries = store.budgets
    .filter(b => b.status === BudgetStatus.ORDER && !b.isDelivered)
    .sort((a, b) => {
      if (!a.deliveryDate) return 1;
      if (!b.deliveryDate) return -1;
      return new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime();
    });

  const selectedBudget = store.budgets.find(b => b.id === selectedBudgetId);
  const selectedCustomer = selectedBudget ? store.customers.find(c => c.id === selectedBudget.customerId) : null;

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-800">Relatório de Entregas Pendentes</h1>
        <p className="text-gray-500">Acompanhe o cronograma de produção e entrega</p>
      </header>

      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-4 font-semibold text-sm text-gray-600">Farol / Prazo</th>
              <th className="px-6 py-4 font-semibold text-sm text-gray-600">Pedido / Produto</th>
              <th className="px-6 py-4 font-semibold text-sm text-gray-600">Cliente / Contato</th>
              <th className="px-6 py-4 font-semibold text-sm text-gray-600">Saldo Pendente</th>
              <th className="px-6 py-4 font-semibold text-sm text-gray-600 text-right">Ação</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {pendingDeliveries.map((item) => {
              const customer = store.customers.find(c => c.id === item.customerId);
              const days = getDaysRemaining(item.deliveryDate);
              const statusClass = getStatusColor(days);
              const statusLabel = getStatusLabel(days);
              
              return (
                <tr key={item.id} className="hover:bg-gray-50 transition group">
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase border ${statusClass}`} title="Indicador de urgência da entrega">
                        <Timer size={12} />
                        {statusLabel}
                      </div>
                      <div className="flex items-center gap-1 text-xs text-gray-400 mt-1 font-medium">
                        <Calendar size={12} />
                        {item.deliveryDate ? new Date(item.deliveryDate + 'T00:00:00').toLocaleDateString('pt-BR') : 'N/A'}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-bold text-gray-900">{item.productName}</p>
                    <p className="text-xs text-[#C5A059] font-black tracking-wider uppercase">{item.orderNumber}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-gray-700 flex items-center gap-1"><User size={12} className="text-gray-400"/> {customer?.name}</span>
                      <span className="text-xs text-gray-500 flex items-center gap-1 font-medium"><Phone size={12} className="text-gray-400"/> {customer?.whatsapp || customer?.phone}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-black px-2.5 py-1.5 rounded-lg bg-red-50 text-red-600 border border-red-100">
                      {formatCurrency(item.remainingValue)}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => setSelectedBudgetId(item.id)}
                      title="Clique para visualizar todos os detalhes técnicos e financeiros deste pedido"
                      className="text-[#C5A059] hover:bg-[#C5A059] hover:text-white p-2 rounded-xl transition-all flex items-center gap-1 ml-auto text-[10px] font-black uppercase tracking-widest border border-transparent hover:border-[#C5A059]/20 shadow-sm"
                    >
                      <Info size={16} /> Ver Dados
                    </button>
                  </td>
                </tr>
              );
            })}
            {pendingDeliveries.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-16 text-center text-gray-400">
                  <div className="bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Truck size={32} className="opacity-20" />
                  </div>
                  <p className="font-medium italic">Tudo em dia! Nenhuma entrega pendente no momento.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Details Modal */}
      {selectedBudget && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-[#FDFBF7] rounded-3xl shadow-2xl w-full max-w-2xl border border-[#C5A059]/30 overflow-hidden max-h-[90vh] flex flex-col">
                <div className="p-6 bg-[#C5A059] text-white flex justify-between items-center flex-shrink-0">
                    <div>
                        <h3 className="font-serif text-xl tracking-widest uppercase">Dados do Pedido</h3>
                        <p className="text-[10px] uppercase opacity-80 tracking-tighter font-black">{selectedBudget.orderNumber}</p>
                    </div>
                    <button onClick={() => setSelectedBudgetId(null)} title="Fechar detalhes" className="hover:rotate-90 transition-transform"><X size={24}/></button>
                </div>
                
                <div className="p-8 overflow-y-auto space-y-8">
                    <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                            <h4 className="flex items-center gap-2 text-[#C5A059] font-black text-[10px] uppercase tracking-widest border-b border-[#C5A059]/10 pb-2"><User size={14}/> Cliente</h4>
                            <div>
                                <p className="font-black text-gray-900 text-lg">{selectedCustomer?.name}</p>
                                <p className="text-sm text-gray-500 font-bold">{selectedCustomer?.whatsapp || selectedCustomer?.phone}</p>
                            </div>
                        </div>
                        <div className="space-y-3">
                            <h4 className="flex items-center gap-2 text-[#C5A059] font-black text-[10px] uppercase tracking-widest border-b border-[#C5A059]/10 pb-2"><Calendar size={14}/> Prazo de Entrega</h4>
                            <div className="text-sm">
                                <p className="text-[#C5A059] font-black text-xl">
                                  {selectedBudget.deliveryDate ? new Date(selectedBudget.deliveryDate + 'T00:00:00').toLocaleDateString('pt-BR') : 'Não informada'}
                                </p>
                                <div className={`inline-block mt-1 px-3 py-1 rounded-full text-[10px] font-black uppercase border ${getStatusColor(getDaysRemaining(selectedBudget.deliveryDate))}`}>
                                  {getStatusLabel(getDaysRemaining(selectedBudget.deliveryDate))}
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="space-y-4">
                        <h4 className="flex items-center gap-2 text-[#C5A059] font-black text-[10px] uppercase tracking-widest border-b border-[#C5A059]/10 pb-2"><Ruler size={14}/> Produto & Detalhes</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white p-4 rounded-2xl border border-gray-100 shadow-inner">
                            <SummaryItem label="Produto" value={selectedBudget.productName} />
                            <SummaryItem label="Tamanho" value={`${selectedBudget.width}x${selectedBudget.height}mm`} />
                            <SummaryItem label="Quantidade" value={`${selectedBudget.quantity} un`} />
                            <SummaryItem label="Margem" value={`${Math.round((selectedBudget.selectedMargin - 1) * 100)}%`} />
                        </div>
                    </section>

                    <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white p-4 rounded-2xl space-y-3 border border-gray-100 shadow-sm">
                             <h4 className="flex items-center gap-2 text-gray-400 font-black text-[10px] uppercase tracking-widest"><Clock size={12}/> Tempos Estimados</h4>
                             <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                                <p className="text-gray-500">Manuseio: <span className="font-black text-gray-800">{selectedBudget.productionTimeMinutes} min</span></p>
                                <p className="text-gray-500">Corte Laser: <span className="font-black text-gray-800">{selectedBudget.machineTimeMinutes} min</span></p>
                                <p className="text-gray-500">Pintura: <span className="font-black text-gray-800">{selectedBudget.paintingTimeMinutes} min</span></p>
                                <p className="text-gray-500">Montagem: <span className="font-black text-gray-800">{selectedBudget.assemblyTimeMinutes} min</span></p>
                             </div>
                        </div>
                        <div className="bg-white p-4 rounded-2xl space-y-3 border border-gray-100 shadow-sm">
                             <h4 className="flex items-center gap-2 text-gray-400 font-black text-[10px] uppercase tracking-widest"><Printer size={12}/> Insumos Gráficos</h4>
                             <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                                <p className="text-gray-500">Impressões: <span className="font-black text-gray-800">{selectedBudget.printingSheets} fls</span></p>
                                <p className="text-gray-500">Laminações: <span className="font-black text-gray-800">{selectedBudget.laminationSheets} fls</span></p>
                             </div>
                        </div>
                    </section>

                    <section className="p-6 bg-[#C5A059] rounded-2xl space-y-4 shadow-xl text-white">
                        <h4 className="flex items-center justify-center gap-2 text-white/70 font-black text-[10px] uppercase tracking-[0.2em]"><Banknote size={16}/> Resumo Financeiro Técnico</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
                            <div>
                                <p className="text-[10px] text-white/60 uppercase font-black">Custo Produção</p>
                                <p className="text-lg font-black">{formatCurrency(selectedBudget.totalBaseCost)}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-green-200 uppercase font-black">Lucro Realizado</p>
                                <p className="text-lg font-black text-green-300">{formatCurrency(selectedBudget.finalPrice - selectedBudget.totalBaseCost)}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-white/60 uppercase font-black">Já Pago (Entrada)</p>
                                <p className="text-lg font-black">{formatCurrency(selectedBudget.downPaymentValue)}</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-white/80 uppercase font-black">Restante na Entrega</p>
                                <p className="text-2xl font-black">{formatCurrency(selectedBudget.remainingValue)}</p>
                            </div>
                        </div>
                        <div className="mt-4 pt-4 border-t border-white/10 text-center">
                           <p className="text-[10px] text-white/60 uppercase font-black">Valor Total do Pedido</p>
                           <p className="text-3xl font-black">{formatCurrency(selectedBudget.finalPrice)}</p>
                        </div>
                        {selectedBudget.isZeroDownPaymentRisk && (
                            <div className="bg-red-600/20 border border-white/20 p-3 rounded-xl text-white text-xs font-black flex items-center justify-center gap-2 animate-pulse uppercase tracking-tighter">
                                <AlertTriangle size={16}/> ATENÇÃO: Pedido sem entrada financeira. Risco para a produção.
                            </div>
                        )}
                    </section>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

const SummaryItem = ({ label, value }: any) => (
    <div className="p-2">
        <p className="text-[9px] text-gray-400 uppercase font-black mb-1 tracking-tighter">{label}</p>
        <p className="font-black text-gray-800 text-sm">{value}</p>
    </div>
);

export default DeliveryReport;
