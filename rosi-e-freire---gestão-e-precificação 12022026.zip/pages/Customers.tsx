
import React, { useState } from 'react';
import { AppState, Customer } from '../types';
import { Plus, Search, Instagram, Phone, MessageSquare, AlertCircle, X, AlertTriangle, Edit2, MessageCircle, ArrowLeft, Hash } from 'lucide-react';

interface Props {
  store: any;
  onBack: () => void;
}

const Customers: React.FC<Props> = ({ store, onBack }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [validationError, setValidationError] = useState<{ title: string, message: string, type: 'error' | 'warning' } | null>(null);
  const [newCustomer, setNewCustomer] = useState({
    name: '', phone: '', whatsapp: '', instagram: '', notes: ''
  });

  const normalize = (val: string) => val.replace(/\D/g, '');

  const handleEditClick = (customer: Customer) => {
    setEditingId(customer.id);
    setNewCustomer({
      name: customer.name,
      phone: customer.phone,
      whatsapp: customer.whatsapp,
      instagram: customer.instagram,
      notes: customer.notes
    });
    setIsAdding(true);
  };

  const handleCancel = () => {
    setIsAdding(false);
    setEditingId(null);
    setNewCustomer({ name: '', phone: '', whatsapp: '', instagram: '', notes: '' });
  };

  const handleSubmit = (e: React.FormEvent | null, forceSave = false) => {
    if (e) e.preventDefault();

    if (!forceSave) {
      const existingByName = store.customers.find((c: Customer) => 
        c.id !== editingId && c.name.trim().toLowerCase() === newCustomer.name.trim().toLowerCase()
      );
      if (existingByName) {
        setValidationError({
          type: 'warning',
          title: 'Nome já cadastrado',
          message: `O cliente "${existingByName.name}" já existe. Deseja salvar como duplicidade?`
        });
        return;
      }

      const searchP = normalize(newCustomer.phone || '');
      const searchW = normalize(newCustomer.whatsapp || '');

      const existingByPhone = store.customers.find((c: Customer) => {
        if (c.id === editingId) return false;
        const cP = normalize(c.phone || '');
        const cW = normalize(c.whatsapp || '');
        return (searchP && (searchP === cP || searchP === cW)) || (searchW && (searchW === cP || searchW === cW));
      });

      if (existingByPhone) {
        setValidationError({
          type: 'warning',
          title: 'Telefone já cadastrado',
          message: `Este contato já pertence ao cliente "${existingByPhone.name}". Salvar como duplicidade?`
        });
        return;
      }

      const searchInsta = newCustomer.instagram.trim().toLowerCase().replace('@', '');
      if (searchInsta) {
        const existingByInsta = store.customers.find((c: Customer) => 
          c.id !== editingId && c.instagram && c.instagram.trim().toLowerCase().replace('@', '') === searchInsta
        );
        if (existingByInsta) {
          setValidationError({
            type: 'warning',
            title: 'Instagram já cadastrado',
            message: `O perfil @${searchInsta} já pertence ao cliente "${existingByInsta.name}". Salvar como duplicidade?`
          });
          return;
        }
      }
    }

    if (editingId) {
      store.updateCustomer(editingId, { ...newCustomer, isDuplicityRisk: forceSave });
    } else {
      store.addCustomer({ ...newCustomer, isDuplicityRisk: forceSave });
    }

    setNewCustomer({ name: '', phone: '', whatsapp: '', instagram: '', notes: '' });
    setIsAdding(false);
    setEditingId(null);
    setValidationError(null);
  };

  const isNameDuplicated = (name: string, currentId: string) => {
    return store.customers.some((c: Customer) => c.id !== currentId && c.name.trim().toLowerCase() === name.trim().toLowerCase());
  };

  const isContactDuplicated = (phone: string, whatsapp: string, currentId: string) => {
    const p = normalize(phone || '');
    const w = normalize(whatsapp || '');
    if (!p && !w) return false;
    return store.customers.some((c: Customer) => {
      if (c.id === currentId) return false;
      const cP = normalize(c.phone || '');
      const cW = normalize(c.whatsapp || '');
      return (p && (p === cP || p === cW)) || (w && (w === cP || w === cW));
    });
  };

  const isInstaDuplicated = (insta: string, currentId: string) => {
    const i = (insta || '').trim().toLowerCase().replace('@', '');
    if (!i) return false;
    return store.customers.some((c: Customer) => {
      if (c.id === currentId) return false;
      return c.instagram && c.instagram.trim().toLowerCase().replace('@', '') === i;
    });
  };

  const filtered = store.customers.filter((c: Customer) => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (c.instagram || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const editingCustomer = editingId ? store.customers.find((c: any) => c.id === editingId) : null;

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 text-[#C5A059] hover:bg-[#C5A059]/10 rounded-xl transition lg:hidden"
            title="Voltar"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Clientes</h1>
            <p className="text-gray-500">Gerencie sua base de clientes</p>
          </div>
        </div>
        {!isAdding && (
          <button 
            onClick={() => setIsAdding(true)}
            title="Adicionar um novo cliente ao sistema"
            className="bg-[#C5A059] text-white px-4 py-2 rounded-lg font-medium hover:brightness-110 transition flex items-center gap-2"
          >
            <Plus size={18} />
            Novo Cliente
          </button>
        )}
      </header>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input 
          type="text" 
          placeholder="Buscar clientes por nome, código ou instagram..."
          className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-[#C5A059] outline-none shadow-sm"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-xl shadow-md border-2 border-[#C5A059]/30 animate-in slide-in-from-top-4">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-black text-[#C5A059] font-serif uppercase tracking-widest flex items-center gap-3">
              {editingId ? 'Editar Cliente' : 'Novo Cliente'}
              {editingCustomer && (
                <span className="text-[10px] bg-[#C5A059] text-white px-3 py-1 rounded-full font-black tracking-widest">
                  {editingCustomer.code}
                </span>
              )}
            </h3>
            {editingId && (
               <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gray-50 border border-gray-100">
                  <span className="text-[9px] font-black text-gray-400 uppercase">Desde:</span>
                  <span className="text-[10px] font-bold text-gray-600">{new Date(editingCustomer?.createdAt).toLocaleDateString('pt-BR')}</span>
               </div>
            )}
          </div>
          
          <form onSubmit={(e) => handleSubmit(e)} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="col-span-1 md:col-span-2">
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Nome / Razão Social</label>
              <input required className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" value={newCustomer.name} onChange={e => setNewCustomer({...newCustomer, name: e.target.value})} />
            </div>
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Telefone</label>
              <input className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" value={newCustomer.phone} onChange={e => setNewCustomer({...newCustomer, phone: e.target.value})} />
            </div>
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">WhatsApp</label>
              <input className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" value={newCustomer.whatsapp} onChange={e => setNewCustomer({...newCustomer, whatsapp: e.target.value})} />
            </div>
            <div className="col-span-1 md:col-span-2">
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-1 flex items-center gap-1">
                <Instagram size={12} className="text-[#C5A059]"/> Perfil do Instagram
              </label>
              <input placeholder="@exemplo" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" value={newCustomer.instagram} onChange={e => setNewCustomer({...newCustomer, instagram: e.target.value})} />
            </div>
            <div className="col-span-1 md:col-span-2">
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Observações Privadas</label>
              <textarea className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 outline-none focus:border-[#C5A059]" rows={2} value={newCustomer.notes} onChange={e => setNewCustomer({...newCustomer, notes: e.target.value})}></textarea>
            </div>
            <div className="col-span-1 md:col-span-2 flex justify-end gap-3 mt-4 pt-4 border-t border-gray-50">
              <button type="button" onClick={handleCancel} className="px-6 py-2 text-gray-400 font-black uppercase text-xs tracking-widest hover:bg-gray-100 rounded-xl transition">Cancelar</button>
              <button type="submit" className="px-8 py-2 bg-[#C5A059] text-white rounded-xl font-black uppercase text-xs tracking-widest shadow-lg hover:brightness-110 transition">
                {editingId ? 'Salvar Alterações' : 'Cadastrar Cliente'}
              </button>
            </div>
          </form>
        </div>
      )}

      {validationError && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden border-t-4 border-orange-500">
            <div className="p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mb-4"><AlertCircle size={28} /></div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{validationError.title}</h3>
              <p className="text-sm text-gray-500 mb-6">{validationError.message}</p>
              <div className="flex flex-col gap-2 w-full">
                <button onClick={() => handleSubmit(null, true)} className="w-full bg-orange-600 text-white py-3 rounded-xl font-bold hover:bg-orange-700 transition">Salvar como Duplicidade</button>
                <button onClick={() => setValidationError(null)} className="w-full bg-gray-200 text-gray-700 py-3 rounded-xl font-bold hover:bg-gray-300 transition">Cancelar</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
              <th className="px-6 py-4">Cód. Registro</th>
              <th className="px-6 py-4">Nome do Cliente</th>
              <th className="px-6 py-4">Contatos</th>
              <th className="px-6 py-4">Data Cadastro</th>
              <th className="px-6 py-4 text-right">Gestão</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {filtered.map((customer: Customer) => {
              const nameDup = isNameDuplicated(customer.name, customer.id);
              const contactDup = isContactDuplicated(customer.phone, customer.whatsapp, customer.id);
              const instaDup = isInstaDuplicated(customer.instagram, customer.id);

              return (
                <tr key={customer.id} className="hover:bg-gray-50/50 transition group">
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-[10px] font-black bg-[#C5A059]/10 text-[#C5A059] border border-[#C5A059]/20 uppercase tracking-widest">
                       {customer.code}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {(nameDup || customer.isDuplicityRisk) && <span className="text-[8px] bg-red-600 text-white px-1.5 py-0.5 rounded font-black tracking-tighter">DUPLICIDADE</span>}
                      <p className="font-bold text-gray-900">{customer.name}</p>
                    </div>
                    {customer.notes && <p className="text-[10px] text-gray-400 italic mt-0.5 truncate max-w-xs">{customer.notes}</p>}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      {customer.whatsapp && (
                        <div className="flex items-center gap-1.5">
                           <a href={`https://wa.me/${normalize(customer.whatsapp)}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 text-xs text-green-600 font-bold hover:underline">
                             <MessageCircle size={12} /> {customer.whatsapp}
                           </a>
                           {contactDup && <span className="w-1.5 h-1.5 bg-red-500 rounded-full" title="Contato Duplicado"></span>}
                        </div>
                      )}
                      {customer.instagram && (
                        <div className="flex items-center gap-1.5 text-xs text-[#C5A059] font-medium">
                          <Instagram size={12}/> {customer.instagram}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-xs text-gray-400 font-medium">{new Date(customer.createdAt).toLocaleDateString('pt-BR')}</p>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition">
                      <button onClick={() => handleEditClick(customer)} className="p-2 text-gray-300 hover:text-[#C5A059] transition" title="Editar Informações"><Edit2 size={18} /></button>
                      <button className="px-3 py-1 text-[10px] font-black text-[#C5A059] uppercase tracking-widest border border-transparent hover:border-[#C5A059]/20 rounded-lg">Histórico</button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Customers;
