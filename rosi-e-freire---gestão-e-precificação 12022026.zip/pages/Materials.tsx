
import React, { useState, useMemo } from 'react';
import { RawMaterial, MaterialType, PriceValidity } from '../types';
import { Plus, Package, Ruler, DollarSign, Edit2, Trash2, Zap, Scroll, ArrowLeft, Calendar, History, X, AlertCircle, Save, Info } from 'lucide-react';
import { calculateMaterialCostPerSqMm, getPriceForDate } from '../utils/calculations';

interface Props {
  store: any;
  onBack: () => void;
}

const Materials: React.FC<Props> = ({ store, onBack }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showHistoryId, setShowHistoryId] = useState<string | null>(null);
  const [duplicateAlert, setDuplicateAlert] = useState<{ name: string, id: string, code: string } | null>(null);
  
  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [editingPriceValue, setEditingPriceValue] = useState<number>(0);

  const [newMaterial, setNewMaterial] = useState<{
    name: string;
    type: MaterialType;
    thickness: number;
    width: number;
    height: number;
    price: number;
    observation: string;
  }>({
    name: '', type: 'LASER', thickness: 3, width: 0, height: 0, price: 0, observation: ''
  });

  const handleEditClick = (material: RawMaterial) => {
    const currentPrice = getPriceForDate(material, new Date().toISOString());
    setEditingId(material.id);
    setNewMaterial({
      name: material.name,
      type: material.type,
      thickness: material.thickness || 0,
      width: material.width || 0,
      height: material.height || 0,
      price: currentPrice,
      observation: material.observation || ''
    });
    setIsAdding(true);
  };

  const handleCancel = () => {
    setIsAdding(false);
    setEditingId(null);
    setDuplicateAlert(null);
    setNewMaterial({ name: '', type: 'LASER', thickness: 3, width: 0, height: 0, price: 0, observation: '' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      store.updateMaterial(editingId, {
        name: newMaterial.name,
        thickness: newMaterial.thickness,
        width: newMaterial.width,
        height: newMaterial.height,
        observation: newMaterial.observation
      });
      
      const material = store.materials.find((m:any) => m.id === editingId);
      const oldPrice = getPriceForDate(material, new Date().toISOString());
      if (newMaterial.price !== oldPrice) {
        store.addMaterialPriceValidity(editingId, newMaterial.price);
      }
    } else {
      const result = store.addMaterial(newMaterial);
      if (!result.success) {
        const existing = store.materials.find((m:any) => m.id === result.existingId);
        setDuplicateAlert({ name: newMaterial.name, id: result.existingId, code: existing.code });
        return;
      }
    }
    handleCancel();
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta matéria-prima? Esta ação não pode ser desfeita.')) {
      store.deleteMaterial(id);
    }
  };

  const handleUpdatePrice = (materialId: string, priceId: string) => {
    store.updateMaterialPriceValidity(materialId, priceId, editingPriceValue);
    setEditingPriceId(null);
  };

  const handleDeletePrice = (materialId: string, priceId: string) => {
    if (confirm('Deseja excluir este registro de preço do histórico?')) {
      store.deleteMaterialPriceValidity(materialId, priceId);
    }
  };

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl lg:hidden"><ArrowLeft size={24}/></button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Matérias-Primas / Produtos</h1>
            <p className="text-gray-500">Gestão de vigência de preços e especificações</p>
          </div>
        </div>
        {!isAdding && (
          <button onClick={() => setIsAdding(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition flex items-center gap-2">
            <Plus size={18} /> Novo Material / Produto
          </button>
        )}
      </header>

      {duplicateAlert && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border-t-8 border-red-500">
              <div className="p-8 text-center space-y-4">
                 <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto"><AlertCircle size={32}/></div>
                 <h3 className="text-xl font-black text-gray-900 uppercase tracking-tight">Produto já cadastrado!</h3>
                 <p className="text-gray-500 text-sm">O material <span className="font-black text-red-600">"{duplicateAlert.name}"</span> já existe sob o código <span className="font-black">{duplicateAlert.code}</span>. O sistema não permite duplicidade de nomes para evitar erros na precificação.</p>
                 <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 text-xs text-left italic">
                    Dica: Se houver diferença técnica ou cor, utilize o campo "Observação" no cadastro já existente.
                 </div>
                 <div className="flex flex-col gap-2 pt-4">
                    <button 
                      onClick={() => {
                        const m = store.materials.find((mat:any) => mat.id === duplicateAlert.id);
                        handleEditClick(m);
                        setDuplicateAlert(null);
                      }} 
                      className="w-full bg-indigo-600 text-white py-3 rounded-xl font-black uppercase text-xs tracking-widest shadow-lg hover:brightness-110"
                    >
                      Editar Registro Existente
                    </button>
                    <button onClick={() => setDuplicateAlert(null)} className="w-full py-3 text-gray-400 font-bold text-xs uppercase hover:bg-gray-100 rounded-xl transition">Fechar Aviso</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {isAdding && !duplicateAlert && (
        <div className="bg-white p-6 rounded-xl shadow-md border border-indigo-100 animate-in slide-in-from-top-4">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold text-indigo-700">{editingId ? 'Editar Registro' : 'Novo Registro'}</h3>
            <div className="flex bg-gray-100 p-1 rounded-xl">
              <button type="button" onClick={() => setNewMaterial({...newMaterial, type: 'LASER'})} className={`px-4 py-1.5 rounded-lg text-xs font-black transition ${newMaterial.type === 'LASER' ? 'bg-[#C5A059] text-white' : 'text-gray-400'}`}>LASER</button>
              <button type="button" onClick={() => setNewMaterial({...newMaterial, type: 'PAPELARIA'})} className={`px-4 py-1.5 rounded-lg text-xs font-black transition ${newMaterial.type === 'PAPELARIA' ? 'bg-[#C5A059] text-white' : 'text-gray-400'}`}>PAPELARIA</button>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="col-span-1 md:col-span-2">
              <label className="block text-xs font-black text-gray-400 uppercase mb-1">Nome do Material / Produto</label>
              <input required className="w-full border rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-500" value={newMaterial.name} onChange={e => setNewMaterial({...newMaterial, name: e.target.value})} placeholder="Ex: MDF Branco 3mm" />
            </div>
            
            <div className="col-span-1 md:col-span-2">
              <label className="block text-xs font-black text-gray-400 uppercase mb-1">Diferenças / Observações do Item</label>
              <input className="w-full border rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-indigo-500" value={newMaterial.observation} onChange={e => setNewMaterial({...newMaterial, observation: e.target.value})} placeholder="Ex: Marca Duratex, Cor Perolizada..." />
            </div>
            
            {newMaterial.type === 'LASER' && (
              <div>
                <label className="block text-xs font-black text-gray-400 uppercase mb-1">Espessura (mm)</label>
                <input type="number" step="0.1" className="w-full border rounded-xl px-4 py-2" value={newMaterial.thickness} onChange={e => setNewMaterial({...newMaterial, thickness: Number(e.target.value)})} />
              </div>
            )}

            <div>
              <label className="block text-xs font-black text-gray-400 uppercase mb-1">{newMaterial.type === 'LASER' ? 'Valor Compra Chapa (R$)' : 'Valor Venda Unitário (R$)'}</label>
              <input type="number" step="0.01" required className="w-full border rounded-xl px-4 py-2" value={newMaterial.price} onChange={e => setNewMaterial({...newMaterial, price: Number(e.target.value)})} />
            </div>

            {newMaterial.type === 'LASER' && (
              <>
                <div><label className="block text-xs font-black text-gray-400 uppercase mb-1">Largura (mm)</label><input type="number" required className="w-full border rounded-xl px-4 py-2" value={newMaterial.width} onChange={e => setNewMaterial({...newMaterial, width: Number(e.target.value)})} /></div>
                <div><label className="block text-xs font-black text-gray-400 uppercase mb-1">Altura (mm)</label><input type="number" required className="w-full border rounded-xl px-4 py-2" value={newMaterial.height} onChange={e => setNewMaterial({...newMaterial, height: Number(e.target.value)})} /></div>
              </>
            )}

            <div className="col-span-1 md:col-span-2 flex justify-end gap-3 mt-4 pt-4 border-t">
              <button type="button" onClick={handleCancel} className="px-4 py-2 text-gray-600 font-bold text-xs uppercase">Cancelar</button>
              <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-200">
                {editingId ? 'Salvar Alterações' : 'Salvar Material'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {store.materials.map((material: RawMaterial) => {
          const isLaser = material.type === 'LASER';
          const currentPrice = getPriceForDate(material, new Date().toISOString());
          
          return (
            <div key={material.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition">
              <div className="p-5">
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-2 rounded-xl ${isLaser ? 'bg-orange-50 text-orange-600' : 'bg-purple-50 text-purple-600'}`}>
                    {isLaser ? <Zap size={20} /> : <Scroll size={20} />}
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => setShowHistoryId(material.id)} className="p-2 text-gray-300 hover:text-indigo-600 transition" title="Ver histórico de vigência"><History size={16}/></button>
                    <button onClick={() => handleEditClick(material)} className="p-2 text-gray-300 hover:text-indigo-600 transition"><Edit2 size={16} /></button>
                    <button onClick={() => handleDelete(material.id)} className="p-2 text-gray-300 hover:text-red-500 transition"><Trash2 size={16} /></button>
                  </div>
                </div>
                <div className="flex items-center gap-2 mb-1">
                   <span className="text-[10px] font-black text-[#C5A059] bg-[#F0E6D2] px-2 py-0.5 rounded uppercase tracking-tighter">{material.code}</span>
                   <h4 className="font-bold text-gray-900 text-lg leading-tight">{material.name}</h4>
                </div>
                {material.observation && <p className="text-[10px] text-gray-400 italic mb-2 truncate" title={material.observation}>{material.observation}</p>}
                
                <div className="flex items-center gap-2 mb-4">
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${isLaser ? 'bg-orange-100 text-orange-700' : 'bg-purple-100 text-purple-700'}`}>
                    {isLaser ? 'Laser' : 'Papelaria'}
                  </span>
                  {isLaser && <p className="text-[10px] font-bold text-gray-400 uppercase">{material.thickness}mm</p>}
                </div>
                
                <div className="space-y-2 border-t pt-3">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400 font-bold uppercase tracking-widest">Preço Vigente</span>
                    <span className="font-black text-gray-800">{formatCurrency(currentPrice)}</span>
                  </div>
                  {isLaser && (
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400 font-bold uppercase tracking-widest">Dimensões</span>
                      <span className="font-bold text-gray-700">{material.width}x{material.height} mm</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Histórico de Vigência */}
      {showHistoryId && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col border border-indigo-100">
               <div className="p-6 bg-indigo-600 text-white flex justify-between items-center">
                   <h3 className="font-bold text-lg">Histórico de Vigências</h3>
                   <button onClick={() => setShowHistoryId(null)}><X size={24}/></button>
               </div>
               <div className="p-6 overflow-y-auto max-h-[60vh] space-y-4">
                  {store.materials.find((m:any) => m.id === showHistoryId)?.prices
                    .sort((a:any, b:any) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime())
                    .map((p: PriceValidity) => (
                    <div key={p.id} className="p-4 bg-gray-50 rounded-2xl border border-gray-100 relative group">
                       <div className="flex justify-between items-center mb-2">
                          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Vigência</span>
                          <div className="flex gap-2 items-center">
                            {p.endDate.startsWith('2999') && <span className="text-[8px] bg-green-500 text-white px-2 py-0.5 rounded-full font-black uppercase">Ativa</span>}
                            <button onClick={() => { setEditingPriceId(p.id); setEditingPriceValue(p.value); }} className="text-gray-400 hover:text-indigo-600 transition"><Edit2 size={14}/></button>
                            <button onClick={() => handleDeletePrice(showHistoryId, p.id)} className="text-gray-400 hover:text-red-500 transition"><Trash2 size={14}/></button>
                          </div>
                       </div>
                       
                       {editingPriceId === p.id ? (
                         <div className="flex items-center gap-2 mt-2">
                            <input type="number" step="0.01" className="flex-1 border rounded-lg px-3 py-1 text-sm outline-none" value={editingPriceValue} onChange={e => setEditingPriceValue(Number(e.target.value))} />
                            <button onClick={() => handleUpdatePrice(showHistoryId, p.id)} className="bg-green-600 text-white p-1.5 rounded-lg"><Save size={16}/></button>
                            <button onClick={() => setEditingPriceId(null)} className="text-gray-400"><X size={16}/></button>
                         </div>
                       ) : (
                         <div className="flex justify-between items-end">
                            <div>
                               <p className="text-xs text-gray-500 font-bold">{new Date(p.startDate).toLocaleDateString('pt-BR')} até {p.endDate.startsWith('2999') ? 'Atualidade' : new Date(p.endDate).toLocaleDateString('pt-BR')}</p>
                               <p className="text-xl font-black text-gray-900">{formatCurrency(p.value)}</p>
                            </div>
                         </div>
                       )}
                    </div>
                  ))}
               </div>
               <div className="p-6 bg-gray-50 border-t">
                  <button onClick={() => setShowHistoryId(null)} className="w-full py-3 bg-white border border-indigo-200 text-indigo-600 rounded-xl font-bold text-xs uppercase tracking-widest">Fechar</button>
               </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Materials;
