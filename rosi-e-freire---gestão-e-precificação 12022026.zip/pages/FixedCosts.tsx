
import React, { useState } from 'react';
import { FixedCostsConfig } from '../types';
import { calculateHourlyFixedCost, calculateMinuteFixedCost } from '../utils/calculations';
import { Plus, Trash2, Save, Calculator, DollarSign, Clock, Cpu } from 'lucide-react';

interface Props {
  store: any;
}

const FixedCosts: React.FC<Props> = ({ store }) => {
  const [config, setConfig] = useState<FixedCostsConfig>(store.fixedCosts);
  const [isSaved, setIsSaved] = useState(false);

  const handleUpdate = () => {
    store.updateFixedCosts(config);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const addItem = () => {
    setConfig({
      ...config,
      items: [...config.items, { id: crypto.randomUUID(), name: '', value: 0 }]
    });
  };

  const removeItem = (id: string) => {
    setConfig({
      ...config,
      items: config.items.filter(i => i.id !== id)
    });
  };

  const updateItem = (id: string, field: 'name' | 'value', value: string | number) => {
    setConfig({
      ...config,
      items: config.items.map(i => i.id === id ? { ...i, [field]: value } : i)
    });
  };

  const hourlyCost = calculateHourlyFixedCost(config);
  const minuteCost = calculateMinuteFixedCost(config);
  const totalFixed = config.items.reduce((acc, i) => acc + i.value, 0);

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Custos Fixos</h1>
          <p className="text-gray-500">Configure seus gastos mensais e valor da hora</p>
        </div>
        <button 
          onClick={handleUpdate}
          title="Salvar todas as configurações de custos e horas para o sistema"
          className={`px-6 py-2 rounded-lg font-medium transition flex items-center gap-2 ${isSaved ? 'bg-green-600 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
        >
          {isSaved ? <Save size={18} /> : <Save size={18} />}
          {isSaved ? 'Alterações Salvas!' : 'Salvar Configuração'}
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <DollarSign size={20} className="text-indigo-600" />
                Planilha de Gastos Mensais
              </h3>
              <button 
                onClick={addItem}
                title="Adicionar uma nova linha de custo fixo mensal"
                className="text-sm font-medium text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <Plus size={16} /> Adicionar Item
              </button>
            </div>

            <div className="space-y-3">
              {config.items.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <input 
                    placeholder="Nome do custo (ex: Aluguel)"
                    className="flex-1 border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
                    value={item.name}
                    onChange={e => updateItem(item.id, 'name', e.target.value)}
                  />
                  <div className="w-40 relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">R$</span>
                    <input 
                      type="number"
                      className="w-full pl-9 pr-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-right"
                      value={item.value || ''}
                      onChange={e => updateItem(item.id, 'value', Number(e.target.value))}
                    />
                  </div>
                  <button 
                    onClick={() => removeItem(item.id)}
                    title="Remover este item de custo fixo"
                    className="p-2 text-gray-400 hover:text-red-600"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              ))}
              <div className="flex justify-between items-center pt-4 border-t font-bold">
                <span>Total de Custos Fixos</span>
                <span>{formatCurrency(totalFixed)}</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
              <Clock size={20} className="text-indigo-600" />
              Parâmetros de Produção
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Salário Desejado (Pro-labore)</label>
                <div className="mt-1 relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">R$</span>
                  <input 
                    type="number"
                    className="w-full pl-9 pr-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                    value={config.desiredSalary}
                    onChange={e => setConfig({ ...config, desiredSalary: Number(e.target.value) })}
                  />
                </div>
                <p className="text-xs text-gray-400 mt-1">Sua meta de ganho pessoal por mês.</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Horas Mensais Disponíveis</label>
                <input 
                  type="number"
                  className="mt-1 w-full px-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                  value={config.monthlyHours}
                  onChange={e => setConfig({ ...config, monthlyHours: Number(e.target.value) })}
                />
                <p className="text-xs text-gray-400 mt-1">Padrão: 220 horas (44h semanais).</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 flex items-center gap-1">
                  <Cpu size={14} className="text-indigo-600" />
                  Valor Hora Máquina (Laser/CNC)
                </label>
                <div className="mt-1 relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">R$</span>
                  <input 
                    type="number"
                    className="w-full pl-9 pr-3 py-2 border rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                    value={config.machineHourRate}
                    onChange={e => setConfig({ ...config, machineHourRate: Number(e.target.value) })}
                  />
                </div>
                <p className="text-xs text-gray-400 mt-1">Sugerido: R$ 45,00/h para manutenção e desgaste.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-600 text-white p-6 rounded-xl shadow-lg">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Calculator size={20} />
              Cálculo de Rateio
            </h3>
            <div className="space-y-4">
              <div className="pb-4 border-b border-indigo-500/50">
                <p className="text-indigo-200 text-xs uppercase tracking-wider font-bold">Custo Total Mensal</p>
                <p className="text-2xl font-bold">{formatCurrency(totalFixed + config.desiredSalary)}</p>
              </div>
              <div>
                <p className="text-indigo-200 text-xs uppercase tracking-wider font-bold">Custo Fixo / Hora</p>
                <p className="text-xl font-bold">{formatCurrency(hourlyCost)}</p>
              </div>
              <div>
                <p className="text-indigo-200 text-xs uppercase tracking-wider font-bold">Custo Fixo / Minuto</p>
                <p className="text-xl font-bold">{formatCurrency(minuteCost)}</p>
              </div>
              <div>
                <p className="text-indigo-200 text-xs uppercase tracking-wider font-bold">Custo Máquina / Hora</p>
                <p className="text-xl font-bold">{formatCurrency(config.machineHourRate)}</p>
              </div>
            </div>
            <p className="text-[10px] text-indigo-300 mt-6 leading-relaxed">
              *Estes valores serão usados automaticamente na formação de preço dos orçamentos, garantindo que todos os seus custos fixos, salário e manutenção de máquinas sejam cobertos pela produção.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FixedCosts;
