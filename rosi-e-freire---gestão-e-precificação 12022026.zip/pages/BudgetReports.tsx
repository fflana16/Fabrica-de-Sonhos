
import React from 'react';
import { BudgetStatus, Budget, Customer } from '../types';
import { FileText, ArrowUpRight, User, Hash, Target, ClipboardX, ExternalLink, ArrowRight } from 'lucide-react';

interface Props {
  store: any;
  onNavigate: (tab: string) => void;
  onPrint: (id: string) => void;
}

const BudgetReports: React.FC<Props> = ({ store, onNavigate, onPrint }) => {
  const budgets = store.budgets as Budget[];
  const customers = store.customers as Customer[];

  const pendingBudgets = budgets.filter(b => b.status === BudgetStatus.BUDGET);
  const convertedBudgets = budgets.filter(b => b.status === BudgetStatus.ORDER);

  // Orçamentos recentes para listagem
  const recentBudgets = [...budgets]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  const customerStats = customers.map(c => {
    const customerBudgets = budgets.filter(b => b.customerId === c.id);
    const converted = customerBudgets.filter(b => b.status === BudgetStatus.ORDER).length;
    return {
      name: c.name,
      total: customerBudgets.length,
      converted,
      pending: customerBudgets.length - converted,
      rate: customerBudgets.length > 0 ? (converted / customerBudgets.length) * 100 : 0
    };
  }).filter(s => s.total > 0).sort((a, b) => b.total - a.total);

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header>
        <h1 className="text-2xl font-bold text-gray-800">Relatórios de Orçamentos</h1>
        <p className="text-gray-500 font-medium tracking-tight">Análise detalhada e acesso rápido aos registros</p>
      </header>

      {/* Cards de Atalho */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <button 
          onClick={() => onNavigate('orders-budget')}
          className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-left hover:border-blue-300 hover:shadow-md transition group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl group-hover:scale-110 transition-transform"><ClipboardX size={24}/></div>
            <ArrowUpRight size={16} className="text-gray-300"/>
          </div>
          <h3 className="font-black text-[10px] uppercase tracking-widest text-gray-400">Orçamentos Pendentes</h3>
          <p className="text-3xl font-black text-gray-900 mt-1">{pendingBudgets.length}</p>
          <p className="text-[10px] text-blue-500 font-bold mt-2 uppercase tracking-tighter">Clique para visualizar</p>
        </button>

        <button 
          onClick={() => onNavigate('orders-active')}
          className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-left hover:border-green-300 hover:shadow-md transition group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-50 text-green-600 rounded-xl group-hover:scale-110 transition-transform"><Target size={24}/></div>
            <ArrowUpRight size={16} className="text-gray-300"/>
          </div>
          <h3 className="font-black text-[10px] uppercase tracking-widest text-gray-400">Orçamentos Convertidos</h3>
          <p className="text-3xl font-black text-gray-900 mt-1">{convertedBudgets.length}</p>
          <p className="text-[10px] text-green-500 font-bold mt-2 uppercase tracking-tighter">Ver pedidos ativos</p>
        </button>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl"><Hash size={24}/></div>
            <h3 className="font-black text-[10px] uppercase tracking-widest text-gray-400">Taxa de Conversão Geral</h3>
          </div>
          <p className="text-3xl font-black text-gray-900 mt-1">
            {budgets.length > 0 ? ((convertedBudgets.length / budgets.length) * 100).toFixed(1) : 0}%
          </p>
          <div className="w-full h-1.5 bg-gray-100 rounded-full mt-4 overflow-hidden">
             <div className="h-full bg-indigo-600" style={{ width: `${budgets.length > 0 ? (convertedBudgets.length / budgets.length) * 100 : 0}%` }} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Listagem de Orçamentos Recentes (Clicáveis) */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-50 bg-gray-50/50">
            <h3 className="font-black text-xs uppercase tracking-widest text-[#C5A059] flex items-center gap-2">
              <FileText size={16}/> Últimos Orçamentos Realizados
            </h3>
          </div>
          <div className="divide-y divide-gray-50">
             {recentBudgets.map(b => (
               <button 
                key={b.id} 
                onClick={() => onPrint(b.id)}
                className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition group"
               >
                 <div className="text-left">
                   <p className="font-bold text-gray-900 text-sm">
                    {b.items[0] ? `${b.items[0].productName} - ${b.items[0].theme}` : 'Sem itens'}
                   </p>
                   <p className="text-[10px] text-gray-400 font-black uppercase tracking-tighter">
                     {customers.find(c => c.id === b.customerId)?.name} • {new Date(b.createdAt).toLocaleDateString('pt-BR')}
                   </p>
                 </div>
                 <div className="flex items-center gap-3">
                   <span className="font-black text-gray-800 text-sm">{formatCurrency(b.totalFinalPrice)}</span>
                   <ExternalLink size={14} className="text-gray-300 group-hover:text-[#C5A059] transition"/>
                 </div>
               </button>
             ))}
             {recentBudgets.length === 0 && (
               <div className="p-10 text-center text-gray-400 italic text-sm">Nenhum orçamento registrado.</div>
             )}
          </div>
        </div>

        {/* Estatísticas por Cliente */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-50 bg-gray-50/50">
            <h3 className="font-black text-xs uppercase tracking-widest text-[#C5A059] flex items-center gap-2">
              <User size={16}/> Eficiência por Cliente
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                <tr>
                  <th className="px-6 py-4">Cliente</th>
                  <th className="px-6 py-4 text-center">T/C</th>
                  <th className="px-6 py-4 text-right">Taxa</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-sm">
                {customerStats.map((stat, i) => (
                  <tr key={i} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4 font-bold text-gray-900">{stat.name}</td>
                    <td className="px-6 py-4 text-center text-gray-500 font-medium">{stat.converted}/{stat.total}</td>
                    <td className="px-6 py-4 text-right">
                      <span className={`font-black ${stat.rate >= 70 ? 'text-green-600' : (stat.rate >= 30 ? 'text-blue-600' : 'text-gray-400')}`}>
                        {stat.rate.toFixed(0)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetReports;
