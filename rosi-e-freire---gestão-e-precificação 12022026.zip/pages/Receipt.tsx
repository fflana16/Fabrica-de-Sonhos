
import React from 'react';
import { BudgetStatus, Budget } from '../types';
import { Printer, ArrowLeft, Instagram, Phone, FileText, History, User, MapPin } from 'lucide-react';
import { Logo } from '../components/Logo';

interface Props {
  budgetId: string;
  store: any;
  onBack: () => void;
}

const Receipt: React.FC<Props> = ({ budgetId, store, onBack }) => {
  const budget = store.budgets.find((b: any) => b.id === budgetId);
  const customer = store.customers.find((c: any) => c.id === budget?.customerId);

  if (!budget || !customer) return <div className="p-20 text-center text-gray-400">Erro ao carregar o registro solicitado.</div>;

  const isOrder = budget.status === BudgetStatus.ORDER;
  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const ReceiptContent = ({ title }: { title: string }) => (
    <div className="h-full flex flex-col p-6 print:p-4 bg-white relative">
      {/* Marcador de Via */}
      <div className="absolute top-2 right-4 text-[8px] font-black uppercase text-gray-300 tracking-[0.2em] border border-gray-100 px-2 py-0.5 rounded">
        {title}
      </div>

      {/* Cabeçalho Reduzido */}
      <div className="text-center mb-4 border-b border-[#C5A059]/20 pb-4">
        <div className="transform scale-[0.65] origin-top -mb-8">
          <Logo />
        </div>
        <div className="flex justify-center gap-4 mt-1 opacity-70">
           <span className="text-[7px] font-black uppercase text-[#8B7355] flex items-center gap-1"><Phone size={8}/> (31) 99444-0225</span>
           <span className="text-[7px] font-black uppercase text-[#8B7355] flex items-center gap-1"><Instagram size={8}/> @rosiefreire_fabricadesonhos</span>
        </div>
      </div>

      {/* Dados do Cliente e Registro */}
      <div className="grid grid-cols-2 gap-4 mb-4 text-[9px]">
        <div>
          <h3 className="font-bold text-gray-400 uppercase tracking-widest text-[7px] mb-1">Cliente</h3>
          <p className="font-bold text-gray-900 leading-tight truncate">{customer.name}</p>
          <p className="text-gray-500">{customer.whatsapp || customer.phone}</p>
          {budget.fiscalType === 'NF' && budget.customerTaxId && (
            <p className="text-gray-400 mt-1">CPF/CNPJ: {budget.customerTaxId}</p>
          )}
        </div>
        <div className="text-right">
          <h3 className="font-bold text-gray-400 uppercase tracking-widest text-[7px] mb-1">Registro</h3>
          <p className="font-black text-gray-900 uppercase">
            {isOrder ? budget.orderNumber : 'Orçamento'}
          </p>
          <p className="text-gray-500">Data: {new Date(budget.createdAt).toLocaleDateString('pt-BR')}</p>
          {budget.deliveryDate && (
            <p className="text-[#C5A059] font-black uppercase text-[8px] mt-0.5">
              Entrega: {new Date(budget.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR')}
            </p>
          )}
        </div>
      </div>

      {/* Tabela de Itens */}
      <div className="flex-1 overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b border-[#C5A059]/30 text-[7px] font-bold text-[#C5A059] uppercase tracking-widest text-left">
              <th className="pb-2">Item</th>
              <th className="pb-2 text-center">Qtd</th>
              <th className="pb-2 text-right">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {budget.items.map((item: any) => (
              <tr key={item.id} className="text-gray-800">
                <td className="py-2 pr-2">
                  <p className="font-bold text-[9px] text-[#8B7355] leading-tight">{item.productName} - {item.theme}</p>
                  {item.observation && <p className="text-[7px] text-gray-400 italic leading-tight truncate max-w-[150px]">{item.observation}</p>}
                </td>
                <td className="py-2 text-center font-bold text-[9px]">{item.quantity}</td>
                <td className="py-2 text-right font-bold text-[9px]">{formatCurrency(item.finalPrice)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Resumo Financeiro */}
      <div className="mt-4 pt-4 border-t border-gray-100 space-y-1">
        <div className="flex justify-between text-[8px] font-bold text-gray-400 uppercase tracking-widest">
          <span>Total Geral</span>
          <span className="text-gray-700">{formatCurrency(budget.totalFinalPrice)}</span>
        </div>
        <div className="flex justify-between text-[8px] font-bold text-green-600 uppercase tracking-widest">
          <span>Sinal Recebido</span>
          <span>{formatCurrency(budget.downPaymentValue)}</span>
        </div>
        <div className="flex justify-between items-center pt-2 border-t border-[#C5A059]/10">
          <span className="text-[9px] font-black text-[#C5A059] uppercase tracking-widest">Saldo Pendente</span>
          <span className="text-lg font-bold text-gray-900">
            {budget.isPaidRemaining ? formatCurrency(0) : formatCurrency(budget.remainingValue)}
          </span>
        </div>
      </div>

      {/* Rodapé e Assinatura com QR Code */}
      <div className="mt-6 pt-4 border-t border-dashed border-gray-200 flex justify-between items-end">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <div className="p-1 border border-gray-100 rounded-lg bg-white shadow-sm">
              <img 
                src="https://api.qrserver.com/v1/create-qr-code/?size=60x60&data=https://www.instagram.com/rosiefreire_fabricadesonhos/" 
                alt="Instagram QR Code" 
                className="w-12 h-12"
              />
            </div>
            <div className="text-[6px] text-gray-400 uppercase font-black tracking-widest">
              Siga no Instagram<br/>
              @rosiefreire_fabricadesonhos
            </div>
          </div>
          <div className="text-[6px] text-gray-400 uppercase font-black tracking-widest">
            Rosi & Freire • Fábrica de Sonhos
          </div>
        </div>
        <div className="w-24 border-t border-gray-300 text-center">
          <span className="text-[6px] text-gray-400 uppercase font-bold tracking-widest">Assinatura</span>
        </div>
      </div>
      
      {budget.isRetroactive && (
        <div className="mt-2 text-center">
           <span className="bg-indigo-600 text-white px-3 py-0.5 rounded-full text-[6px] font-black uppercase tracking-widest">Pedido Retroativo</span>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100/50 print:bg-white">
      <header className="no-print p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 max-w-4xl mx-auto">
        <button onClick={onBack} className="flex items-center gap-2 text-[#C5A059] font-bold uppercase text-xs tracking-[0.2em] hover:opacity-70 transition">
          <ArrowLeft size={18} /> Voltar
        </button>
        <div className="flex gap-3">
          <span className="hidden md:flex items-center text-[10px] font-bold text-gray-400 uppercase tracking-widest">A4 Paisagem • 2 Vias</span>
          <button onClick={() => window.print()} className="bg-[#C5A059] text-white px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:brightness-110 transition flex items-center gap-2">
            <Printer size={20} /> Imprimir 2 Vias (A4 Paisagem)
          </button>
        </div>
      </header>

      {/* Grid de Impressão (Lado a Lado em Paisagem) */}
      <div className="print:w-[297mm] print:h-[210mm] print:flex print:flex-row print:items-stretch bg-white shadow-2xl print:shadow-none mx-auto overflow-hidden flex flex-col md:flex-row border-x border-gray-100 max-w-[297mm]">
        {/* Via do Cliente (Esquerda) */}
        <div className="flex-1 border-r-2 border-dashed border-gray-200 print:border-r-2 print:border-gray-200 relative">
          <ReceiptContent title="Via do Cliente" />
          {/* Linha de Corte - Apenas Visual na Tela */}
          <div className="absolute right-0 top-0 bottom-0 translate-x-1/2 flex flex-col justify-around text-gray-300 no-print">
            <div className="rotate-90 text-[10px] font-black uppercase tracking-widest">Corte Aqui</div>
          </div>
        </div>
        
        {/* Via da Loja (Direita) */}
        <div className="flex-1 relative">
          <ReceiptContent title="Via da Loja" />
        </div>
      </div>

      <footer className="no-print mt-10 pb-10 text-center text-gray-400 text-[10px] font-bold uppercase tracking-widest">
        Dica: Certifique-se que as configurações de margem da sua impressora estão como "Nenhuma" para melhor aproveitamento.
      </footer>
    </div>
  );
};

export default Receipt;
