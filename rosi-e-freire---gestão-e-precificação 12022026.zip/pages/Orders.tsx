
import React, { useState, useEffect } from 'react';
import { AppState, BudgetStatus, PaymentMethod, Budget } from '../types';
import { 
  FileText, CheckCircle, ArrowRight, Receipt, Trash2, Edit2, 
  Calendar, Banknote, Truck, Info, X, AlertTriangle, User, 
  Ruler, Clock, Printer, Layers, Instagram, Church, Zap, 
  Scroll, CreditCard, CheckCircle2, Layers as MixedIcon, 
  Timer, AlertCircle, Hash, DollarSign 
} from 'lucide-react';

interface Props {
  store: any;
  onPrint: (id: string) => void;
  onEdit: (id: string) => void;
  initialFilter?: any;
}

const Orders: React.FC<Props> = ({ store, onPrint, onEdit, initialFilter = 'ALL' }) => {
  const [filter, setFilter] = useState<string>(initialFilter);
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'LASER' | 'PAPELARIA' | 'MIXED'>('ALL');
  const [farolFilter, setFarolFilter] = useState<'ALL' | 'VERDE' | 'AMARELO' | 'VERMELHO'>('ALL');
  
  const [approvingId, setApprovingId] = useState<string | null>(null);
  const [deliveringId, setDeliveringId] = useState<string | null>(null);
  const [summaryId, setSummaryId] = useState<string | null>(null);

  const [deliveryDate, setDeliveryDate] = useState('');
  const [selectedItemsForOrder, setSelectedItemsForOrder] = useState<string[]>([]);
  const [delayJustification, setDelayJustification] = useState('');
  const [finalPaymentDate, setFinalPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [finalDeliveryDate, setFinalDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [finalPaymentMethod, setFinalPaymentMethod] = useState<PaymentMethod>('PIX');
  const [amountReceived, setAmountReceived] = useState<number>(0);

  const approvingBudget = approvingId ? store.budgets.find((b: any) => b.id === approvingId) : null;
  const summaryBudget = summaryId ? store.budgets.find((b: any) => b.id === summaryId) : null;
  const deliveringBudget = deliveringId ? store.budgets.find((b: any) => b.id === deliveringId) : null;

  useEffect(() => {
    if (initialFilter) setFilter(initialFilter);
  }, [initialFilter]);

  useEffect(() => {
    if (approvingId && approvingBudget) {
      setSelectedItemsForOrder(approvingBudget.items.map((i: any) => i.id));
      setDeliveryDate(new Date().toISOString().split('T')[0]);
    } else {
      setSelectedItemsForOrder([]);
      setDeliveryDate('');
    }
  }, [approvingId, approvingBudget]);

  useEffect(() => {
    if (deliveringId && deliveringBudget) {
      setAmountReceived(deliveringBudget.remainingValue || 0);
      setDelayJustification('');
      setFinalDeliveryDate(new Date().toISOString().split('T')[0]);
      setFinalPaymentDate(new Date().toISOString().split('T')[0]);
    }
  }, [deliveringId, deliveringBudget]);

  const getFarol = (budget: Budget) => {
    if (budget.status === BudgetStatus.BUDGET && !budget.isRetroactive) return null;
    
    if (budget.isDelivered && budget.deliveryDate && budget.finalPaymentDate) {
      const [y, m, d] = budget.deliveryDate.split('-').map(Number);
      const expected = new Date(y, m - 1, d).getTime();
      const actual = new Date(budget.finalPaymentDate).getTime();
      
      if (actual < expected) return { color: 'bg-green-600', text: 'Antecipado', icon: <CheckCircle2 size={10}/>, code: 'VERDE' };
      if (actual === expected) return { color: 'bg-blue-600', text: 'No Prazo', icon: <CheckCircle2 size={10}/>, code: 'VERDE' };
      return { color: 'bg-red-600', text: 'Atrasado', icon: <AlertCircle size={10}/>, code: 'VERMELHO' };
    }

    if (!budget.deliveryDate) return null;
    const [y, m, d] = budget.deliveryDate.split('-').map(Number);
    const delivery = new Date(y, m - 1, d);
    delivery.setHours(0,0,0,0);
    const today = new Date();
    today.setHours(0,0,0,0);
    const diff = delivery.getTime() - today.getTime();
    const days = Math.round(diff / (1000 * 60 * 60 * 24));
    
    if (days < 0) return { color: 'bg-red-500', text: 'Atrasado', icon: <AlertCircle size={10}/>, code: 'VERMELHO' };
    if (days <= 1) return { color: 'bg-yellow-500', text: 'No Limite', icon: <Timer size={10}/>, code: 'AMARELO' };
    return { color: 'bg-green-500', text: 'No Prazo', icon: <CheckCircle2 size={10}/>, code: 'VERDE' };
  };

  const filtered = store.budgets.filter((b: any) => {
    let stateMatch = true;
    if (filter === 'BUDGET') {
      stateMatch = b.status === BudgetStatus.BUDGET && !b.isRetroactive;
    } else if (filter === 'ORDER_PENDING') {
      stateMatch = b.status === BudgetStatus.ORDER && !b.isDelivered && !b.isRetroactive;
    } else if (filter === 'ORDER_DELIVERED') {
      stateMatch = b.status === BudgetStatus.ORDER && b.isDelivered && !b.isRetroactive;
    } else if (filter === 'RETROACTIVE') {
      stateMatch = b.isRetroactive === true;
    }

    const farol = getFarol(b);
    const farolMatch = farolFilter === 'ALL' || (farol && farol.code === farolFilter);

    let typeMatch = true;
    const hasLaser = b.items.some((i: any) => i.budgetType === 'LASER');
    const hasPaper = b.items.some((i: any) => i.budgetType === 'PAPELARIA');

    if (typeFilter === 'LASER') typeMatch = hasLaser && !hasPaper;
    else if (typeFilter === 'PAPELARIA') typeMatch = hasPaper && !hasLaser;
    else if (typeFilter === 'MIXED') typeMatch = hasLaser && hasPaper;

    return stateMatch && typeMatch && farolMatch;
  });

  const sorted = [...filtered].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const handleApprove = () => {
    if (!approvingId) return;
    if (!deliveryDate) {
      alert('Informe a data de entrega.');
      return;
    }
    if (selectedItemsForOrder.length === 0) {
      alert('Selecione pelo menos um item para gerar o pedido.');
      return;
    }
    store.convertToOrder(approvingId, deliveryDate, selectedItemsForOrder);
    setApprovingId(null);
  };

  const handleConfirmDelivery = () => {
    if (!deliveringId) return;
    const budget = store.budgets.find((b: any) => b.id === deliveringId);
    
    if (budget?.deliveryDate) {
        const [y, m, d] = budget.deliveryDate.split('-').map(Number);
        const expected = new Date(y, m - 1, d).getTime();
        const actual = new Date(finalDeliveryDate + 'T12:00:00').getTime();
        if (actual > expected && !delayJustification) {
            alert('Este pedido está sendo entregue com atraso. Uma justificativa é obrigatória para controle de eficácia.');
            return;
        }
    }

    store.markAsDeliveredAndPaid(
      deliveringId, 
      finalPaymentMethod, 
      new Date(finalPaymentDate + 'T12:00:00').toISOString(),
      new Date(finalDeliveryDate + 'T12:00:00').toISOString(),
      amountReceived,
      delayJustification
    );
    setDeliveringId(null);
  };

  const isDelayed = deliveringBudget && deliveringBudget.deliveryDate 
    ? new Date(finalDeliveryDate + 'T12:00:00').getTime() > new Date(deliveringBudget.deliveryDate + 'T12:00:00').getTime()
    : false;

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Orçamentos & Pedidos</h1>
          <p className="text-gray-500 font-medium">Gestão e monitoramento de fluxo de trabalho</p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-2">
            <div className="flex bg-white p-1 rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <button onClick={() => setFilter('ALL')} className={`px-4 py-1.5 text-[9px] font-black uppercase rounded-lg transition ${filter === 'ALL' ? 'bg-[#C5A059] text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}>Todos</button>
                <button onClick={() => setFilter('BUDGET')} className={`px-4 py-1.5 text-[9px] font-black uppercase rounded-lg transition ${filter === 'BUDGET' ? 'bg-[#C5A059] text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}>Orçamentos</button>
                <button onClick={() => setFilter('ORDER_PENDING')} className={`px-4 py-1.5 text-[9px] font-black uppercase rounded-lg transition ${filter === 'ORDER_PENDING' ? 'bg-[#C5A059] text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}>Pendentes</button>
                <button onClick={() => setFilter('ORDER_DELIVERED')} className={`px-4 py-1.5 text-[9px] font-black uppercase rounded-lg transition ${filter === 'ORDER_DELIVERED' ? 'bg-[#C5A059] text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}>Entregues</button>
                <button onClick={() => setFilter('RETROACTIVE')} className={`px-4 py-1.5 text-[9px] font-black uppercase rounded-lg transition ${filter === 'RETROACTIVE' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}>Retroativos</button>
            </div>

            <div className="flex bg-white p-1 rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <select 
                  className="text-[9px] font-black uppercase px-2 py-1 bg-transparent outline-none text-[#C5A059]"
                  value={farolFilter}
                  onChange={(e) => setFarolFilter(e.target.value as any)}
                >
                  <option value="ALL">Farol: Todos</option>
                  <option value="VERDE">Verde</option>
                  <option value="AMARELO">Amarelo</option>
                  <option value="VERMELHO">Vermelho</option>
                </select>
            </div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {sorted.map((item: Budget) => {
          const customer = store.customers.find((c: any) => c.id === item.customerId);
          const isBudget = item.status === BudgetStatus.BUDGET;
          const farol = getFarol(item);
          const laserItems = item.items.filter(i => i.budgetType === 'LASER');
          const paperItems = item.items.filter(i => i.budgetType === 'PAPELARIA');
          const isMixed = laserItems.length > 0 && paperItems.length > 0;

          return (
            <div key={item.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition duration-300 relative overflow-hidden">
              {farol && <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${farol.color}`} title={farol.text} />}
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className={`p-4 rounded-2xl ${isBudget ? 'bg-blue-50 text-blue-600' : (item.isDelivered ? 'bg-gray-50 text-gray-400' : 'bg-green-50 text-green-600')}`}>
                    {isMixed ? <MixedIcon size={24} /> : (laserItems.length > 0 ? <Zap size={24} /> : <Scroll size={24} />)}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {farol && <span className={`flex items-center gap-1 text-[8px] font-black uppercase text-white px-2 py-0.5 rounded ${farol.color}`}>{farol.icon} {farol.text}</span>}
                      {item.isRetroactive && <span className="bg-indigo-600 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded tracking-widest">PEDIDO RETROATIVO</span>}
                      <h4 className="font-bold text-gray-900 leading-tight">
                        {item.items[0] ? `${item.items[0].productName} - ${item.items[0].theme}` : 'Pedido sem itens'}
                      </h4>
                      <span className="text-[9px] bg-[#C5A059]/10 text-[#C5A059] px-2 py-0.5 rounded-full font-black tracking-tighter uppercase">{item.orderNumber || item.code}</span>
                    </div>
                    <p className="text-xs font-black text-gray-400 uppercase tracking-tighter">[{customer?.code}] {customer?.name}</p>
                    <div className="flex flex-col gap-0.5 mt-1">
                      {item.deliveryDate && (
                        <p className={`text-sm font-black ${farol?.code === 'VERMELHO' ? 'text-red-500' : 'text-indigo-600'}`}>
                          Entrega: {new Date(item.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR')}
                        </p>
                      )}
                      <p className="text-[10px] text-gray-400 font-medium">
                        {isBudget ? 'Orçado em' : (item.isRetroactive ? 'Vendido em' : 'Pedido em')}: {new Date(item.createdAt).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-8 px-8 border-x border-gray-50">
                  <div className="text-center">
                    <p className="text-[9px] text-gray-400 uppercase font-black tracking-widest mb-1">Total</p>
                    <p className="font-black text-gray-900">{formatCurrency(item.totalFinalPrice)}</p>
                  </div>
                  {!item.isDelivered && (
                    <div className="text-center">
                      <p className="text-[9px] text-gray-400 uppercase font-black tracking-widest mb-1">Saldo</p>
                      <p className="font-black text-red-500">{formatCurrency(item.remainingValue)}</p>
                    </div>
                  )}
                  {item.isDelivered && (
                    <div className="text-center">
                      <p className="text-[9px] text-green-600 uppercase font-black tracking-widest mb-1">Finalizado</p>
                      <p className="font-black text-green-600"><CheckCircle2 size={16} className="inline"/></p>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={() => setSummaryId(item.id)} className="p-2 text-gray-300 hover:text-[#C5A059] transition" title="Detalhes técnicos"><Info size={20}/></button>
                  {isBudget && <button onClick={() => onEdit(item.id)} className="p-2 text-gray-300 hover:text-indigo-600 transition" title="Editar"><Edit2 size={20} /></button>}
                  {isBudget ? (
                    <button onClick={() => setApprovingId(item.id)} className="bg-[#C5A059] text-white px-6 py-2 rounded-xl font-black text-xs uppercase shadow-lg hover:brightness-110">Aprovar</button>
                  ) : !item.isDelivered && (
                    <button onClick={() => setDeliveringId(item.id)} className="bg-green-600 text-white px-6 py-2 rounded-xl font-black text-xs uppercase shadow-lg hover:brightness-110 flex items-center gap-2" title="Entregar"><Truck size={14}/> Entregar</button>
                  )}
                  <button onClick={() => onPrint(item.id)} className="p-2 text-gray-300 hover:text-[#C5A059] transition" title="Imprimir"><Printer size={20}/></button>
                  <button onClick={() => { if(confirm('Excluir este registro permanentemente?')) store.deleteBudget(item.id); }} className="p-2 text-gray-300 hover:text-red-500 transition" title="Excluir"><Trash2 size={20} /></button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Modal de Aprovação */}
      {approvingId && approvingBudget && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col border border-[#C5A059]/20">
               <div className="p-6 bg-[#C5A059] text-white flex justify-between items-center">
                   <h3 className="font-serif text-xl tracking-widest uppercase flex items-center gap-3"><CheckCircle size={24}/> Aprovar Orçamento</h3>
                   <button onClick={() => setApprovingId(null)}><X size={24}/></button>
               </div>
               <div className="p-8 space-y-6">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">Data Prevista de Entrega</label>
                    <input type="date" className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 font-black text-[#C5A059] outline-none focus:border-[#C5A059]" value={deliveryDate} onChange={e => setDeliveryDate(e.target.value)} />
                  </div>
                  <div className="p-4 bg-orange-50 rounded-2xl border border-orange-100 flex items-center gap-3 text-orange-700">
                     <AlertTriangle size={20} className="flex-shrink-0" />
                     <p className="text-[10px] font-bold leading-tight uppercase">Ao aprovar, o orçamento se torna um pedido oficial com número de acompanhamento. Alterações serão bloqueadas.</p>
                  </div>
               </div>
               <div className="p-6 bg-gray-50 border-t flex gap-4">
                  <button onClick={() => setApprovingId(null)} className="flex-1 py-4 text-gray-400 font-black uppercase text-xs tracking-widest hover:bg-gray-100 rounded-2xl transition">Cancelar</button>
                  <button onClick={handleApprove} className="flex-[2] bg-[#C5A059] text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg hover:brightness-110 transition">Confirmar Pedido</button>
               </div>
           </div>
        </div>
      )}

      {/* Resumo Técnico com QR Code */}
      {summaryId && summaryBudget && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
           <div className="bg-[#FDFBF7] rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col border border-[#C5A059]/30 max-h-[90vh]">
               <div className="p-6 bg-[#C5A059] text-white flex justify-between items-center">
                   <div className="flex items-center gap-4">
                      <div className="p-1 bg-white rounded-lg shadow-inner">
                        <img 
                          src="https://api.qrserver.com/v1/create-qr-code/?size=50x50&data=https://www.instagram.com/rosiefreire_fabricadesonhos/" 
                          alt="QR Code" 
                          className="w-10 h-10"
                        />
                      </div>
                      <div>
                        <h3 className="font-serif text-xl tracking-widest uppercase">Resumo Técnico</h3>
                        <p className="text-[10px] uppercase font-black opacity-80">{summaryBudget.orderNumber || summaryBudget.code}</p>
                      </div>
                   </div>
                   <button onClick={() => setSummaryId(null)}><X size={24}/></button>
               </div>
               <div className="p-8 overflow-y-auto space-y-8">
                  <section className="grid grid-cols-2 gap-6">
                      <div className="space-y-1">
                          <h4 className="text-[10px] font-black text-[#C5A059] uppercase tracking-widest border-b border-[#C5A059]/10 pb-1 flex items-center gap-2"><User size={12}/> Cliente</h4>
                          <p className="font-black text-gray-900">
                             {store.customers.find((c: any) => c.id === summaryBudget.customerId)?.name || 'Cliente não encontrado'}
                          </p>
                      </div>
                      <div className="space-y-1 text-right">
                          <h4 className="text-[10px] font-black text-[#C5A059] uppercase tracking-widest border-b border-[#C5A059]/10 pb-1 flex items-center justify-end gap-2"><Calendar size={12}/> Data Entrega</h4>
                          <p className="font-black text-[#C5A059] text-lg">
                            {summaryBudget.deliveryDate ? new Date(summaryBudget.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'Não agendada'}
                          </p>
                      </div>
                  </section>

                  <section className="space-y-4">
                     <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><Layers size={14}/> Composição</h4>
                     <div className="space-y-3">
                        {summaryBudget.items.map((item: any) => (
                           <div key={item.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex justify-between items-center">
                              <div>
                                 <p className="font-black text-gray-900">{item.productName} - {item.theme}</p>
                                 <p className="text-[10px] text-[#C5A059] font-black uppercase">QTD: {item.quantity} un</p>
                              </div>
                              <p className="font-black text-gray-900">{formatCurrency(item.finalPrice)}</p>
                           </div>
                        ))}
                     </div>
                  </section>

                  <section className="bg-[#C5A059] p-6 rounded-3xl text-white shadow-xl flex justify-between items-center">
                    <div>
                      <p className="text-[10px] font-black text-white/60 uppercase">Saldo Pendente</p>
                      <p className="text-3xl font-black">{formatCurrency(summaryBudget.remainingValue)}</p>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-white/60 uppercase">Total do Pedido</p>
                       <p className="text-xl font-bold">{formatCurrency(summaryBudget.totalFinalPrice)}</p>
                    </div>
                  </section>
               </div>
               <div className="p-6 bg-gray-50 border-t">
                   <button onClick={() => setSummaryId(null)} className="w-full py-4 bg-white border-2 border-gray-100 rounded-2xl font-black text-xs uppercase text-gray-400 hover:bg-gray-100 transition tracking-widest">Fechar Detalhes</button>
               </div>
           </div>
        </div>
      )}

      {/* Modal de Entrega */}
      {deliveringId && deliveringBudget && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
           <div className={`bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col border ${isDelayed ? 'border-red-500 ring-4 ring-red-500/10' : 'border-green-200'}`}>
               <div className={`p-6 text-white flex justify-between items-center ${isDelayed ? 'bg-red-600' : 'bg-green-600'}`}>
                   <h3 className="font-serif text-xl tracking-widest uppercase flex items-center gap-3">
                     {isDelayed ? <AlertTriangle size={24}/> : <Truck size={24}/>} 
                     {isDelayed ? 'Entrega em Atraso' : 'Finalizar Entrega'}
                   </h3>
                   <button onClick={() => setDeliveringId(null)}><X size={24}/></button>
               </div>
               <div className="p-8 space-y-6 max-h-[70vh] overflow-y-auto">
                  <div className={`p-4 rounded-2xl border flex justify-between items-center ${isDelayed ? 'bg-red-50 border-red-100' : 'bg-green-50 border-green-100'}`}>
                     <div>
                       <p className={`text-[10px] font-black uppercase mb-1 ${isDelayed ? 'text-red-700' : 'text-green-700'}`}>Prazo Acordado</p>
                       <p className={`font-black ${isDelayed ? 'text-red-900' : ''}`}>{deliveringBudget.deliveryDate ? new Date(deliveringBudget.deliveryDate + 'T12:00:00').toLocaleDateString('pt-BR') : 'N/A'}</p>
                     </div>
                     <div className="text-right">
                       <p className={`text-[10px] font-black uppercase mb-1 ${isDelayed ? 'text-red-700' : 'text-green-700'}`}>Saldo Pendente</p>
                       <p className={`text-xl font-black ${isDelayed ? 'text-red-900' : 'text-green-900'}`}>{formatCurrency(deliveringBudget.remainingValue)}</p>
                     </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Data Efetiva Entrega</label>
                      <input type="date" className="w-full border-2 border-gray-100 rounded-xl px-4 py-2 font-black" value={finalDeliveryDate} onChange={e => setFinalDeliveryDate(e.target.value)} />
                    </div>
                  </div>

                  {isDelayed && (
                    <div className="animate-in slide-in-from-top-2">
                        <label className="block text-[10px] font-black text-red-600 uppercase mb-1 flex items-center gap-1">
                          <AlertCircle size={12}/> Justificativa de Atraso (Obrigatório)
                        </label>
                        <textarea 
                            required 
                            className="w-full border-2 border-red-500 rounded-xl px-4 py-3 bg-red-50 text-sm font-medium outline-none focus:ring-4 focus:ring-red-500/20 text-red-900" 
                            rows={3} 
                            placeholder="Descreva detalhadamente o motivo do atraso..."
                            value={delayJustification}
                            onChange={e => setDelayJustification(e.target.value)}
                        />
                    </div>
                  )}

                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-[10px] font-black text-gray-400 uppercase mb-1">Forma de Pagamento (Saldo)</label>
                      <select className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 font-black bg-white" value={finalPaymentMethod} onChange={e => setFinalPaymentMethod(e.target.value as PaymentMethod)}>
                        <option value="PIX">PIX</option>
                        <option value="Dinheiro">Dinheiro</option>
                        <option value="Débito">Débito</option>
                        <option value="Crédito">Crédito</option>
                      </select>
                    </div>
                  </div>
               </div>
               <div className="p-6 bg-gray-50 border-t flex gap-4">
                  <button onClick={() => setDeliveringId(null)} className="flex-1 py-4 text-gray-400 font-black uppercase text-xs tracking-widest hover:bg-gray-100 rounded-2xl transition">Cancelar</button>
                  <button onClick={handleConfirmDelivery} className={`flex-[2] text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg hover:brightness-110 transition ${isDelayed ? 'bg-red-600' : 'bg-green-600'}`}>
                    {isDelayed ? 'Registrar Atraso e Entregar' : 'Confirmar Entrega'}
                  </button>
               </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Orders;
