
import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Music, Upload, Loader2 } from 'lucide-react';
import { getAudioFromDB, saveAudioToDB } from '../utils/audioStorage';

export const AmbientMusic: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume] = useState(() => {
    const saved = localStorage.getItem('ambient_volume');
    return saved ? parseFloat(saved) : 0.2;
  });
  const [audioSrc, setAudioSrc] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const initAudio = async () => {
      try {
        const blob = await getAudioFromDB();
        if (blob) {
          const url = URL.createObjectURL(blob);
          setAudioSrc(url);
          
          // Attempt auto-play after a small delay
          setTimeout(() => {
            if (audioRef.current) {
              audioRef.current.play().then(() => {
                setIsPlaying(true);
              }).catch(() => {
                console.log("Autoplay blocked, waiting for user interaction.");
              });
            }
          }, 1000);
        }
      } catch (err) {
        console.error("Audio error:", err);
      } finally {
        setIsLoading(false);
      }
    };
    initAudio();
  }, []);

  const togglePlay = () => {
    if (!audioSrc) {
      fileInputRef.current?.click();
      return;
    }

    if (isPlaying) {
      audioRef.current?.pause();
      setIsPlaying(false);
    } else {
      audioRef.current?.play().then(() => {
        setIsPlaying(true);
      });
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setAudioSrc(url);
      await saveAudioToDB(file);
      if (audioRef.current) {
        audioRef.current.src = url;
        audioRef.current.play().then(() => setIsPlaying(true));
      }
    }
  };

  if (isLoading) return null;

  return (
    <div className="fixed top-6 right-8 z-[200] no-print">
      <div className="flex items-center gap-2">
        {!audioSrc && (
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="text-[10px] font-black uppercase tracking-widest text-[#C5A059] bg-white/50 backdrop-blur px-3 py-1.5 rounded-full border border-[#C5A059]/30 hover:bg-white transition flex items-center gap-2 shadow-sm"
          >
            <Upload size={12} /> Carregar Som
          </button>
        )}
        
        <button 
          onClick={togglePlay}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 shadow-md ${
            isPlaying 
              ? 'bg-[#C5A059] text-white ring-4 ring-[#C5A059]/20' 
              : 'bg-white text-[#C5A059] border border-[#C5A059]/30'
          }`}
          title={audioSrc ? (isPlaying ? "Desativar Áudio" : "Ativar Áudio") : "Selecionar Música"}
        >
          {isPlaying ? (
            <div className="relative flex items-center justify-center">
              <Volume2 size={18} />
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
              </span>
            </div>
          ) : <VolumeX size={18} />}
        </button>

        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="audio/*" className="hidden" />
        <audio ref={audioRef} loop src={audioSrc || undefined} />
      </div>
    </div>
  );
};
