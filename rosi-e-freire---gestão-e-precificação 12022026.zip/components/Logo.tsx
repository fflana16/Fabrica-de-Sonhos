
import React from 'react';

export const Logo: React.FC<{ variant?: 'light' | 'dark' }> = ({ variant = 'dark' }) => {
  const color = variant === 'dark' ? '#C5A059' : '#FFFFFF';
  return (
    <div className="flex flex-col items-center text-center select-none py-4">
      <div className="mb-1">
        <svg width="120" height="30" viewBox="0 0 120 30" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 15C30 5 90 5 110 15" stroke={color} strokeWidth="1" strokeLinecap="round"/>
          <circle cx="60" cy="8" r="3" fill={color} />
          <path d="M50 12C55 10 65 10 70 12" stroke={color} strokeWidth="1" />
        </svg>
      </div>
      <h1 className="text-3xl font-serif tracking-widest uppercase font-light" style={{ color }}>
        Rosi & Freire
      </h1>
      <p className="text-xs tracking-[0.3em] uppercase mt-1 opacity-80" style={{ color }}>
        Fábrica de Sonhos
      </p>
      <div className="mt-1">
        <svg width="120" height="20" viewBox="0 0 120 20" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 5C30 15 90 15 110 5" stroke={color} strokeWidth="1" strokeLinecap="round"/>
        </svg>
      </div>
    </div>
  );
};
