
import { useState, useEffect } from 'react';
import { AppState, Customer, RawMaterial, FixedCostsConfig, Budget, PaymentMethod, PriceValidity, BudgetStatus } from './types';

const STORAGE_KEY = 'rosi_freire_factory_v1';

const initialFixedCosts: FixedCostsConfig = {
  desiredSalary: 5000,
  monthlyHours: 220,
  machineHourRate: 45,
  items: [
    { id: '1', name: 'Aluguel', value: 0 },
    { id: '2', name: 'Água', value: 0 },
    { id: '3', name: 'Energia', value: 0 },
    { id: '4', name: 'Internet', value: 0 },
    { id: '5', name: 'Manutenção', value: 0 },
  ]
};

const initialState: AppState = {
  customers: [],
  materials: [],
  fixedCosts: initialFixedCosts,
  budgets: [],
  counters: {
    customer: 0,
    material: 0,
    budget: 0,
    order: 0,
    retro: 0
  }
};

export const useAppState = () => {
  const [state, setState] = useState<AppState>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return initialState;
    const parsed = JSON.parse(stored);
    if (parsed.fixedCosts && parsed.fixedCosts.machineHourRate === undefined) {
      parsed.fixedCosts.machineHourRate = 45;
    }
    if (!parsed.counters) {
      parsed.counters = { customer: parsed.customers.length, material: parsed.materials.length, budget: parsed.budgets.length, order: 0, retro: 0 };
    }
    return parsed;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const generateCode = (type: keyof AppState['counters'], prefix: string) => {
    const nextVal = (state.counters[type] || 0) + 1;
    return `${prefix}-${nextVal.toString().padStart(3, '0')}`;
  };

  const addCustomer = (customer: Omit<Customer, 'id' | 'createdAt' | 'code'>) => {
    const id = crypto.randomUUID();
    const code = generateCode('customer', 'CLI');
    const newCustomer = {
      ...customer,
      id,
      code,
      createdAt: new Date().toISOString()
    };
    setState(prev => ({ 
      ...prev, 
      customers: [...prev.customers, newCustomer],
      counters: { ...prev.counters, customer: prev.counters.customer + 1 }
    }));
    return newCustomer;
  };

  const updateCustomer = (id: string, customerData: Partial<Customer>) => {
    setState(prev => ({
      ...prev,
      customers: prev.customers.map(c => c.id === id ? { ...c, ...customerData } : c)
    }));
  };

  const addMaterial = (materialData: { name: string, type: any, thickness: number, width: number, height: number, price: number, observation?: string }) => {
    const existing = state.materials.find(m => m.name.trim().toLowerCase() === materialData.name.trim().toLowerCase());
    if (existing) {
      return { success: false, existingId: existing.id };
    }

    const id = crypto.randomUUID();
    const code = generateCode('material', 'MAT');
    const now = new Date();
    
    const newPrice: PriceValidity = {
      id: crypto.randomUUID(),
      value: materialData.price,
      startDate: now.toISOString(),
      endDate: '2999-12-31T23:59:59.999Z'
    };

    const newMaterial: RawMaterial = {
      id,
      code,
      name: materialData.name,
      type: materialData.type,
      thickness: materialData.thickness,
      width: materialData.width,
      height: materialData.height,
      prices: [newPrice],
      observation: materialData.observation
    };

    setState(prev => ({ 
      ...prev, 
      materials: [...prev.materials, newMaterial],
      counters: { ...prev.counters, material: prev.counters.material + 1 }
    }));
    return { success: true, material: newMaterial };
  };

  const updateMaterialPriceValidity = (materialId: string, priceId: string, newValue: number, newStartDate?: string, newEndDate?: string) => {
    setState(prev => ({
      ...prev,
      materials: prev.materials.map(m => {
        if (m.id !== materialId) return m;
        return {
          ...m,
          prices: m.prices.map(p => {
            if (p.id !== priceId) return p;
            return { 
              ...p, 
              value: newValue, 
              ...(newStartDate && { startDate: newStartDate }),
              ...(newEndDate && { endDate: newEndDate })
            };
          })
        };
      })
    }));
  };

  const deleteMaterialPriceValidity = (materialId: string, priceId: string) => {
    setState(prev => ({
      ...prev,
      materials: prev.materials.map(m => {
        if (m.id !== materialId) return m;
        if (m.prices.length <= 1) return m;
        return {
          ...m,
          prices: m.prices.filter(p => p.id !== priceId)
        };
      })
    }));
  };

  const addMaterialPriceValidity = (materialId: string, newValue: number, newStartDateStr?: string) => {
    setState(prev => {
      const now = newStartDateStr ? new Date(newStartDateStr) : new Date();
      
      const newMaterials = prev.materials.map(m => {
        if (m.id !== materialId) return m;

        const updatedPrices = m.prices.map(p => {
          if (p.endDate.startsWith('2999')) {
            const dayBefore = new Date(now);
            dayBefore.setDate(dayBefore.getDate() - 1);
            dayBefore.setHours(23, 59, 59, 999);
            return { ...p, endDate: dayBefore.toISOString() };
          }
          return p;
        });

        const newPrice: PriceValidity = {
          id: crypto.randomUUID(),
          value: newValue,
          startDate: now.toISOString(),
          endDate: '2999-12-31T23:59:59.999Z'
        };

        return { ...m, prices: [...updatedPrices, newPrice] };
      });

      return { ...prev, materials: newMaterials };
    });
  };

  const updateMaterial = (id: string, materialData: Partial<RawMaterial>) => {
    setState(prev => ({
      ...prev,
      materials: prev.materials.map(m => m.id === id ? { ...m, ...materialData } : m)
    }));
  };

  const deleteMaterial = (id: string) => {
    setState(prev => ({
      ...prev,
      materials: prev.materials.filter(m => m.id !== id)
    }));
  };

  const updateFixedCosts = (config: FixedCostsConfig) => {
    setState(prev => ({ ...prev, fixedCosts: config }));
  };

  const addBudget = (budget: Omit<Budget, 'id' | 'createdAt' | 'code'> & { createdAt?: string }) => {
    const isRetroactive = budget.status === BudgetStatus.ORDER;
    const type = isRetroactive ? 'retro' : 'budget';
    const prefix = isRetroactive ? 'RET' : 'ORC';
    const code = generateCode(type, prefix);
    
    const newBudget: Budget = {
      ...budget,
      id: crypto.randomUUID(),
      code,
      createdAt: budget.createdAt || new Date().toISOString(),
      orderNumber: isRetroactive ? code : undefined,
      orderDate: isRetroactive ? (budget.createdAt || new Date().toISOString()) : undefined,
    } as Budget;

    setState(prev => ({ 
      ...prev, 
      budgets: [...prev.budgets, newBudget],
      counters: { ...prev.counters, [type]: prev.counters[type] + 1 }
    }));
  };

  const updateBudget = (id: string, budgetData: Partial<Budget>) => {
    setState(prev => ({
      ...prev,
      budgets: prev.budgets.map(b => b.id === id ? { ...b, ...budgetData } : b)
    }));
  };

  const convertToOrder = (budgetId: string, deliveryDate: string, selectedItemIds: string[]) => {
    setState(prev => {
      const orderCode = `${prev.counters.order + 1}`.padStart(3, '0');
      const fullOrderCode = `PED-${orderCode}`;

      return {
        ...prev,
        counters: { ...prev.counters, order: prev.counters.order + 1 },
        budgets: prev.budgets.map(b => {
          if (b.id !== budgetId) return b;
          const keptItems = b.items.filter(item => selectedItemIds.includes(item.id));
          const newTotalFinal = keptItems.reduce((acc, item) => acc + item.finalPrice, 0);
          const newTotalBase = keptItems.reduce((acc, item) => acc + item.totalBaseCost, 0);
          return {
            ...b,
            items: keptItems,
            totalFinalPrice: newTotalFinal,
            totalBaseCost: newTotalBase,
            status: BudgetStatus.ORDER,
            orderDate: new Date().toISOString(),
            orderNumber: fullOrderCode,
            deliveryDate,
            remainingValue: Math.max(0, newTotalFinal - b.downPaymentValue),
            isPaidRemaining: false,
            isDelivered: false
          };
        })
      };
    });
  };

  const markAsDeliveredAndPaid = (budgetId: string, method: PaymentMethod, paymentDate?: string, deliveredDate?: string, amountReceived?: number, delayJustification?: string) => {
    setState(prev => ({
      ...prev,
      budgets: prev.budgets.map(b => {
        if (b.id !== budgetId) return b;
        
        const dDate = deliveredDate || new Date().toISOString();
        const pDate = paymentDate || new Date().toISOString();
        
        let earlyDeliveryNote = '';
        if (b.deliveryDate) {
          const expected = new Date(b.deliveryDate).getTime();
          const actual = new Date(dDate).getTime();
          if (actual < expected) {
            earlyDeliveryNote = `Entrega antecipada realizada em ${new Date(actual).toLocaleDateString('pt-BR')}`;
          }
        }

        return { 
          ...b, 
          isPaidRemaining: true, 
          paymentMethodBalance: method,
          isDelivered: true,
          finalPaymentDate: pDate,
          deliveryDate: dDate.split('T')[0],
          earlyDeliveryNote,
          delayJustification,
          amountReceivedAtDelivery: amountReceived ?? b.remainingValue
        };
      })
    }));
  };

  const deleteBudget = (id: string) => {
    setState(prev => ({ ...prev, budgets: prev.budgets.filter(b => b.id !== id) }));
  };

  return {
    ...state,
    addCustomer,
    updateCustomer,
    addMaterial,
    addMaterialPriceValidity,
    updateMaterialPriceValidity,
    deleteMaterialPriceValidity,
    updateMaterial,
    deleteMaterial,
    updateFixedCosts,
    addBudget,
    updateBudget,
    convertToOrder,
    markAsDeliveredAndPaid,
    deleteBudget
  };
};
